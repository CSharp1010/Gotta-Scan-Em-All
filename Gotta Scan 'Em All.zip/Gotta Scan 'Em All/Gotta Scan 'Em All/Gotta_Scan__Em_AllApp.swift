//
//  Gotta_Scan__Em_AllApp.swift
//  Gotta Scan 'Em All
//
//  Created by Jersain Hermosillo on 9/8/25.
//

import SwiftUI

@main
struct Gotta_Scan__Em_AllApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

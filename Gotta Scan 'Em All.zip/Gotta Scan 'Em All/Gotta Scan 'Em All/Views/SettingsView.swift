//
//  SettingsView.swift
//  Gotta Scan 'Em All
//
//  Created by Jersain Hermosillo on 9/8/25.
//

import SwiftUI

struct AppSettingsView: View {
    @EnvironmentObject var cardCollection: CardCollection
    @AppStorage("appTheme") private var appThemeRawValue: String = AppTheme.system.rawValue
    @State private var showingExportAlert = false
    @State private var showingImportAlert = false
    @State private var showingDeleteAlert = false
    
    var body: some View {
        NavigationView {
            List {
                // Appearance Settings
                Section("Appearance") {
                    Picker("Theme", selection: Binding<AppTheme>(
                        get: { AppTheme(rawValue: appThemeRawValue) ?? .system },
                        set: { appThemeRawValue = $0.rawValue }
                    )) {
                        ForEach(AppTheme.allCases) { theme in
                            Text(theme.label).tag(theme)
                        }
                    }
                    .pickerStyle(.segmented)
                }
                
                // Collection Management
                Section("Collection") {
                    HStack {
                        Image(systemName: "square.and.arrow.up")
                            .foregroundColor(.blue)
                        Text("Export Collection")
                        Spacer()
                        Image(systemName: "chevron.right")
                            .foregroundColor(.gray)
                            .font(.caption)
                    }
                    .contentShape(Rectangle())
                    .onTapGesture {
                        showingExportAlert = true
                    }
                    
                    HStack {
                        Image(systemName: "plus.circle")
                            .foregroundColor(.green)
                        Text("Load Sample Data")
                        Spacer()
                        Image(systemName: "chevron.right")
                            .foregroundColor(.gray)
                            .font(.caption)
                    }
                    .contentShape(Rectangle())
                    .onTapGesture {
                        loadSampleData()
                    }
                    
                    HStack {
                        Image(systemName: "square.and.arrow.down")
                            .foregroundColor(.green)
                        Text("Import Collection")
                        Spacer()
                        Image(systemName: "chevron.right")
                            .foregroundColor(.gray)
                            .font(.caption)
                    }
                    .contentShape(Rectangle())
                    .onTapGesture {
                        showingImportAlert = true
                    }
                    
                    HStack {
                        Image(systemName: "trash")
                            .foregroundColor(.red)
                        Text("Clear All Cards")
                        Spacer()
                        Image(systemName: "chevron.right")
                            .foregroundColor(.gray)
                            .font(.caption)
                    }
                    .contentShape(Rectangle())
                    .onTapGesture {
                        showingDeleteAlert = true
                    }
                }
                
                // App Information
                Section("About") {
                    HStack {
                        Image(systemName: "info.circle")
                            .foregroundColor(.blue)
                        Text("App Version")
                        Spacer()
                        Text("1.0.0")
                            .foregroundColor(.secondary)
                    }
                    
                    HStack {
                        Image(systemName: "heart.fill")
                            .foregroundColor(.red)
                        Text("Made with ❤️")
                        Spacer()
                    }
                }
                
                // Collection Stats
                Section("Your Collection") {
                    HStack {
                        Image(systemName: "square.grid.3x3")
                            .foregroundColor(.blue)
                        Text("Total Cards")
                        Spacer()
                        Text("\(cardCollection.cards.count)")
                            .foregroundColor(.secondary)
                    }
                    
                    HStack {
                        Image(systemName: "dollarsign.circle")
                            .foregroundColor(.green)
                        Text("Collection Value")
                        Spacer()
                        Text(String(format: "$%.2f", cardCollection.totalValue))
                            .foregroundColor(.secondary)
                    }
                    
                    HStack {
                        Image(systemName: "folder")
                            .foregroundColor(.orange)
                        Text("Unique Sets")
                        Spacer()
                        Text("\(cardCollection.uniqueSets.count)")
                            .foregroundColor(.secondary)
                    }
                }
            }
            .navigationTitle("Settings")
            .alert("Export Collection", isPresented: $showingExportAlert) {
                Button("Cancel", role: .cancel) { }
                Button("Export") {
                    exportCollection()
                }
            } message: {
                Text("This will create a backup file of your collection that you can share or restore later.")
            }
            .alert("Import Collection", isPresented: $showingImportAlert) {
                Button("Cancel", role: .cancel) { }
                Button("Import") {
                    importCollection()
                }
            } message: {
                Text("This will replace your current collection with the imported data. Make sure to backup your current collection first.")
            }
            .alert("Clear All Cards", isPresented: $showingDeleteAlert) {
                Button("Cancel", role: .cancel) { }
                Button("Delete All", role: .destructive) {
                    clearAllCards()
                }
            } message: {
                Text("This will permanently delete all cards in your collection. This action cannot be undone.")
            }
        }
    }
    
    private func exportCollection() {
        // TODO: Implement collection export functionality
        print("Exporting collection...")
    }
    
    private func importCollection() {
        // TODO: Implement collection import functionality
        print("Importing collection...")
    }
    
    private func loadSampleData() {
        SampleData.populateSampleData(in: cardCollection)
    }
    
    private func clearAllCards() {
        cardCollection.cards.removeAll()
        cardCollection.totalValue = 0.0
        // Save the empty collection
        if let encoded = try? JSONEncoder().encode(cardCollection.cards) {
            UserDefaults.standard.set(encoded, forKey: "SavedCards")
        }
    }
}

#Preview {
    AppSettingsView()
        .environmentObject(CardCollection())
}

//
//  ScannerView.swift
//  Gotta Scan 'Em All
//
//  Created by Jersain Hermosillo on 9/8/25.
//

import SwiftUI
import AVFoundation
#if canImport(UIKit)
import UIKit
#endif

#if targetEnvironment(simulator)
struct PhotoPickerFallbackView: View {
    var onCancel: () -> Void
    var onImagePicked: (_ image: UIImage?) -> Void
    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: "photo")
                .font(.system(size: 48))
                .foregroundColor(.blue)
            Text("Camera Not Available in Simulator")
                .font(.headline)
            Text("Use the photo library or test on a device.")
                .font(.subheadline)
                .foregroundColor(.secondary)
            HStack {
                Button("Cancel") { onCancel() }
                    .buttonStyle(.bordered)
                Button("Choose Photo") {
                    // Placeholder: in your project, you can integrate PHPicker here and call onImagePicked
                    onImagePicked(nil)
                }
                .buttonStyle(.borderedProminent)
            }
        }
        .padding()
    }
}
#endif

struct ScannerView: View {
    private enum ActiveSheet: Identifiable {
        case camera, manual
        var id: Int {
            switch self {
            case .camera: return 1
            case .manual: return 2
            }
        }
    }
    @State private var activeSheet: ActiveSheet? = nil
    @EnvironmentObject var cardCollection: CardCollection
    @StateObject private var imageProcessor = ImageProcessor()
    @StateObject private var recognitionService = CardRecognitionService(apiService: PokemonTCGAPIService.shared)
    @State private var showingPhotoPicker = false
    @State private var pickedImage: UIImage?
    @State private var showConfirmation = false
    @State private var recognizedCard: PokemonCard?
    @State private var detectedText: [String] = []
    @State private var isProcessing = false
    
    var body: some View {
        NavigationView {
            VStack(spacing: 30) {
                // Header
                VStack(spacing: 10) {
                    Image(systemName: "camera.viewfinder")
                        .font(.system(size: 60))
                        .foregroundColor(.blue)
                    
                    Text("Scan Pokémon Cards")
                        .font(.title)
                        .fontWeight(.bold)
                    
                    Text("Select a card from your gallery to scan and add it to your collection")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                }
                
                Spacer()
                
                // Action Buttons
                VStack(spacing: 20) {
                    Button(action: {
                        showingPhotoPicker = true
                    }) {
                        HStack {
                            if isProcessing {
                                ProgressView()
                                    .progressViewStyle(CircularProgressViewStyle(tint: .white))
                                    .scaleEffect(0.8)
                            } else {
                                Image(systemName: "photo.on.rectangle")
                            }
                            Text(isProcessing ? "Processing..." : "Scan Card")
                        }
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(isProcessing ? Color.gray : Color.blue)
                        .cornerRadius(12)
                    }
                    .disabled(isProcessing)
                    
                    Button(action: {
                        DispatchQueue.main.async {
                            activeSheet = .manual
                        }
                    }) {
                        HStack {
                            Image(systemName: "pencil")
                            Text("Add Manually")
                        }
                        .font(.headline)
                        .foregroundColor(.blue)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue.opacity(0.1))
                        .cornerRadius(12)
                    }
                }
                .padding(.horizontal)
                
                Spacer()
                
                // Collection Stats
                VStack(spacing: 8) {
                    Text("Your Collection")
                        .font(.headline)
                    
                    HStack(spacing: 30) {
                        VStack {
                            Text("\(cardCollection.cards.count)")
                                .font(.title2)
                                .fontWeight(.bold)
                            Text("Cards")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        
                        VStack {
                            Text(String(format: "$%.2f", cardCollection.totalValue))
                                .font(.title2)
                                .fontWeight(.bold)
                            Text("Value")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                }
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(12)
                .padding(.horizontal)
            }
            .navigationTitle("Scanner")
            .sheet(item: $activeSheet) { sheet in
                switch sheet {
                case .camera:
                    CameraView()
                        .environmentObject(cardCollection)
                        .environmentObject(imageProcessor)
                case .manual:
                    ManualEntryView()
                        .environmentObject(cardCollection)
                }
            }
            .sheet(isPresented: $showingPhotoPicker) {
                ImagePicker(selectedImage: $pickedImage)
            }
            .onChange(of: pickedImage) { image in
                guard let image = image else { return }
                processSelectedImage(image)
            }
            .sheet(isPresented: $showConfirmation) {
                if let card = recognizedCard {
                    CardConfirmationView(
                        card: card, 
                        capturedImage: pickedImage,
                        detectedText: detectedText
                    )
                    .environmentObject(cardCollection)
                }
            }
        }
    }
    
    private func processSelectedImage(_ image: UIImage) {
        print("🔄 Starting image processing...")
        isProcessing = true
        
        // Add a timeout to prevent infinite processing (increased to 90 seconds for slow API)
        var timeoutTask: Task<Void, Never>?
        var hasCompleted = false // Track if recognition has completed
        
        timeoutTask = Task {
            try? await Task.sleep(nanoseconds: 90_000_000_000) // 90 seconds
            // Only show timeout if we're still processing and recognition hasn't completed
            if !hasCompleted && isProcessing && !showConfirmation {
                print("⏱️ Timeout reached after 90 seconds, showing fallback card")
                await MainActor.run {
                    isProcessing = false
                    recognizedCard = PokemonCard(
                        name: "Scanned Card",
                        set: "Unknown Set",
                        number: "?/?",
                        rarity: .common,
                        hp: nil,
                        types: [],
                        marketValue: nil
                    )
                    showConfirmation = true
                }
            }
        }
        
        print("🔍 Starting card recognition...")
        recognitionService.recognizeCard(from: image) { result in
            print("✅ Recognition completed, result: \(result != nil ? "found" : "nil")")
            hasCompleted = true // Mark as completed
            timeoutTask?.cancel() // Cancel timeout since we got a result
            
            DispatchQueue.main.async {
                // Only update if we haven't already shown the confirmation screen from timeout
                guard !showConfirmation else {
                    print("⚠️ Confirmation already shown (timeout), but updating with recognition result")
                    // Even if timeout already showed, update with the actual result if we got one
                    if let result = result, let suggested = result.suggestedCard {
                        recognizedCard = suggested
                    }
                    return
                }
                
                isProcessing = false
                
                if let result = result {
                    // Store detected text for manual editing
                    detectedText = result.detectedText
                    
                    if let suggested = result.suggestedCard {
                        print("✅ Card recognized: \(suggested.name)")
                        recognizedCard = suggested
                    } else {
                        print("⚠️ Recognition failed, using fallback card")
                        // Fallback to a generic card if recognition fails
                        recognizedCard = PokemonCard(
                            name: "Scanned Card",
                            set: "Unknown Set",
                            number: "?/?",
                            rarity: .common,
                            hp: nil,
                            types: [],
                            marketValue: nil
                        )
                    }
                } else {
                    // No result at all, use empty detected text
                    detectedText = []
                    print("⚠️ Recognition failed, using fallback card")
                    recognizedCard = PokemonCard(
                        name: "Scanned Card",
                        set: "Unknown Set",
                        number: "?/?",
                        rarity: .common,
                        hp: nil,
                        types: [],
                        marketValue: nil
                    )
                }
                print("📋 Showing confirmation screen")
                showConfirmation = true
            }
        }
    }
}

#Preview {
    ScannerView()
        .environmentObject(CardCollection())
}

//
//  CollectionView.swift
//  Gotta Scan 'Em All
//
//  Created by Jersain Hermosillo on 9/8/25.
//

import SwiftUI

struct CollectionView: View {
    @EnvironmentObject var cardCollection: CardCollection
    @State private var searchText = ""
    @State private var selectedFilter: FilterOption = .all
    @State private var showingFilters = false
    
    enum FilterOption: String, CaseIterable {
        case all = "All Cards"
        case bySet = "By Set"
        case byRarity = "By Rarity"
        case byType = "By Type"
    }
    
    var filteredCards: [PokemonCard] {
        var cards = cardCollection.searchCards(query: searchText)
        
        switch selectedFilter {
        case .all:
            return cards
        case .bySet:
            return cards.sorted { $0.set < $1.set }
        case .byRarity:
            return cards.sorted { $0.rarity.rawValue < $1.rarity.rawValue }
        case .byType:
            return cards.sorted { $0.types.first?.rawValue ?? "" < $1.types.first?.rawValue ?? "" }
        }
    }
    
    var body: some View {
        NavigationView {
            VStack {
                if cardCollection.cards.isEmpty {
                    EmptyCollectionView()
                } else {
                    // Search Bar
                    SearchBar(text: $searchText)
                        .padding(.horizontal)
                    
                    // Filter Options
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 12) {
                            ForEach(FilterOption.allCases, id: \.self) { option in
                                FilterChip(
                                    title: option.rawValue,
                                    isSelected: selectedFilter == option
                                ) {
                                    selectedFilter = option
                                }
                            }
                        }
                        .padding(.horizontal)
                    }
                    
                    // Cards Grid
                    ScrollView {
                        LazyVGrid(columns: [
                            GridItem(.flexible()),
                            GridItem(.flexible())
                        ], spacing: 16) {
                            ForEach(filteredCards) { card in
                                NavigationLink(destination: CardDetailView(card: card)) {
                                    CardGridView(card: card)
                                }
                                .buttonStyle(PlainButtonStyle())
                            }
                        }
                        .padding()
                    }
                }
            }
            .navigationTitle("Collection")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        showingFilters = true
                    }) {
                        Image(systemName: "line.3.horizontal.decrease.circle")
                    }
                }
            }
            .sheet(isPresented: $showingFilters) {
                FilterView(selectedFilter: $selectedFilter)
            }
        }
    }
}

struct EmptyCollectionView: View {
    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "square.grid.3x3")
                .font(.system(size: 60))
                .foregroundColor(.gray)
            
            Text("No Cards Yet")
                .font(.title2)
                .fontWeight(.semibold)
            
            Text("Start scanning Pokémon cards to build your digital collection!")
                .font(.subheadline)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

struct SearchBar: View {
    @Binding var text: String
    
    var body: some View {
        HStack {
            Image(systemName: "magnifyingglass")
                .foregroundColor(.gray)
            
            TextField("Search cards...", text: $text)
                .textFieldStyle(PlainTextFieldStyle())
            
            if !text.isEmpty {
                Button(action: {
                    text = ""
                }) {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(.gray)
                }
            }
        }
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(10)
    }
}

struct FilterChip: View {
    let title: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.caption)
                .fontWeight(.medium)
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(isSelected ? Color.blue : Color(.systemGray5))
                .foregroundColor(isSelected ? .white : .primary)
                .cornerRadius(16)
        }
    }
}

struct CardGridView: View {
    let card: PokemonCard
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            // Card Image
            CardImageView(card: card, aspectRatio: 0.7, cornerRadius: 8)
            
            // Card Info
            VStack(alignment: .leading, spacing: 4) {
                Text(card.name)
                    .font(.headline)
                    .lineLimit(2)
                
                Text(card.set)
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                HStack {
                    Text(card.number)
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    Spacer()
                    
                    RarityBadge(rarity: card.rarity)
                }
            }
        }
        .padding(8)
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: 1)
    }
}

struct RarityBadge: View {
    let rarity: CardRarity
    
    var body: some View {
        Text(rarity.rawValue)
            .font(.caption2)
            .fontWeight(.medium)
            .padding(.horizontal, 6)
            .padding(.vertical, 2)
            .background(rarity.color.opacity(0.2))
            .foregroundColor(rarity.color)
            .cornerRadius(4)
    }
}

struct FilterView: View {
    @Binding var selectedFilter: CollectionView.FilterOption
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        NavigationView {
            List {
                ForEach(CollectionView.FilterOption.allCases, id: \.self) { option in
                    Button(action: {
                        selectedFilter = option
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        HStack {
                            Text(option.rawValue)
                            Spacer()
                            if selectedFilter == option {
                                Image(systemName: "checkmark")
                                    .foregroundColor(.blue)
                            }
                        }
                    }
                    .foregroundColor(.primary)
                }
            }
            .navigationTitle("Filter Options")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        presentationMode.wrappedValue.dismiss()
                    }
                }
            }
        }
    }
}

#Preview {
    CollectionView()
        .environmentObject(CardCollection())
}

//
//  ManualEditView.swift
//  Gotta Scan 'Em All
//
//  Created by Jersain Hermosillo on 9/8/25.
//

import SwiftUI

struct ManualEditView: View {
    @Binding var card: PokemonCard
    let detectedText: [String]
    @Environment(\.presentationMode) var presentationMode
    
    // Form fields
    @State private var cardName: String
    @State private var cardSet: String
    @State private var cardNumber: String
    @State private var selectedRarity: CardRarity
    @State private var hp: String
    @State private var selectedTypes: Set<PokemonType>
    @State private var marketValue: String
    @State private var artist: String
    @State private var showingDetectedText = true
    
    init(card: Binding<PokemonCard>, detectedText: [String] = []) {
        self._card = card
        self.detectedText = detectedText
        self._cardName = State(initialValue: card.wrappedValue.name)
        self._cardSet = State(initialValue: card.wrappedValue.set)
        self._cardNumber = State(initialValue: card.wrappedValue.number)
        self._selectedRarity = State(initialValue: card.wrappedValue.rarity)
        self._hp = State(initialValue: card.wrappedValue.hp?.description ?? "")
        self._selectedTypes = State(initialValue: Set(card.wrappedValue.types))
        self._marketValue = State(initialValue: card.wrappedValue.marketValue?.description ?? "")
        self._artist = State(initialValue: card.wrappedValue.artist ?? "")
    }
    
    var body: some View {
        NavigationView {
            Form {
                // Detected Text Section (if available)
                if !detectedText.isEmpty {
                    Section {
                        HStack {
                            Text("Scanned Text")
                                .font(.headline)
                            Spacer()
                            Button(action: {
                                showingDetectedText.toggle()
                            }) {
                                Image(systemName: showingDetectedText ? "chevron.up" : "chevron.down")
                                    .font(.caption)
                                    .foregroundColor(.blue)
                            }
                        }
                        
                        if showingDetectedText {
                            VStack(alignment: .leading, spacing: 4) {
                                ForEach(detectedText, id: \.self) { text in
                                    Text(text)
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                        .padding(.vertical, 2)
                                }
                            }
                            .padding(.vertical, 4)
                            
                            Text("Tap and hold text to copy, then paste into fields above")
                                .font(.caption2)
                                .foregroundColor(.secondary)
                                .italic()
                        }
                    } header: {
                        Text("Helpful Text from Scan")
                    } footer: {
                        Text("Use the scanned text to help fill in the card details below")
                    }
                }
                
                Section("Basic Information") {
                    TextField("Card Name", text: $cardName)
                    TextField("Set Name", text: $cardSet)
                    TextField("Card Number", text: $cardNumber)
                    
                    Picker("Rarity", selection: $selectedRarity) {
                        ForEach(CardRarity.allCases, id: \.self) { rarity in
                            Text(rarity.rawValue).tag(rarity)
                        }
                    }
                }
                
                Section("Card Stats") {
                    TextField("HP (optional)", text: $hp)
                        .keyboardType(.numberPad)
                    
                    TextField("Market Value (optional)", text: $marketValue)
                        .keyboardType(.decimalPad)
                    
                    TextField("Artist (optional)", text: $artist)
                }
                
                Section("Types") {
                    LazyVGrid(columns: [
                        GridItem(.flexible()),
                        GridItem(.flexible()),
                        GridItem(.flexible())
                    ], spacing: 8) {
                        ForEach(PokemonType.allCases, id: \.self) { type in
                            TypeSelectionButton(
                                type: type,
                                isSelected: selectedTypes.contains(type)
                            ) {
                                if selectedTypes.contains(type) {
                                    selectedTypes.remove(type)
                                } else {
                                    selectedTypes.insert(type)
                                }
                            }
                        }
                    }
                }
            }
            .navigationTitle("Edit Card")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        presentationMode.wrappedValue.dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") {
                        saveChanges()
                    }
                    .disabled(cardName.isEmpty || cardSet.isEmpty || cardNumber.isEmpty)
                }
            }
        }
    }
    
    private func saveChanges() {
        let hpValue = Int(hp.trimmingCharacters(in: .whitespacesAndNewlines)) ?? nil
        let value = parseDecimalString(marketValue)
        
        card = PokemonCard(
            name: cardName,
            set: cardSet,
            number: cardNumber,
            rarity: selectedRarity,
            imageURL: card.imageURL,
            localImagePath: card.localImagePath,
            hp: hpValue,
            types: Array(selectedTypes),
            attacks: card.attacks,
            weaknesses: card.weaknesses,
            resistances: card.resistances,
            retreatCost: card.retreatCost,
            artist: artist.isEmpty ? nil : artist,
            marketValue: value
        )
        
        presentationMode.wrappedValue.dismiss()
    }

    private func parseDecimalString(_ text: String) -> Double? {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty { return nil }
        let allowed = CharacterSet(charactersIn: "0123456789.")
        let filtered = String(trimmed.unicodeScalars.filter { allowed.contains($0) })
        return Double(filtered)
    }
}

#Preview {
    ManualEditView(card: .constant(PokemonCard(
        name: "Pikachu",
        set: "Base Set",
        number: "58/102",
        rarity: .common,
        hp: 40,
        types: [.lightning],
        marketValue: 5.99
    )))
}

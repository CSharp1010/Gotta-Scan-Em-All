//
//  ManualEntryView.swift
//  Gotta Scan 'Em All
//
//  Created by Jersain Hermosillo on 9/8/25.
//

import SwiftUI

struct ManualEntryView: View {
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var cardCollection: CardCollection
    @State private var showingSuccess = false
    @State private var isAdding = false
    
    // Form fields
    @State private var cardName = ""
    @State private var cardSet = ""
    @State private var cardNumber = ""
    @State private var selectedRarity: CardRarity = .common
    @State private var hp = ""
    @State private var selectedTypes: Set<PokemonType> = []
    @State private var marketValue = ""
    @State private var artist = ""
    
    var body: some View {
        NavigationView {
            Form {
                Section("Basic Information") {
                    TextField("Card Name", text: $cardName)
                    TextField("Set Name", text: $cardSet)
                    TextField("Card Number", text: $cardNumber)
                    
                    Picker("Rarity", selection: $selectedRarity) {
                        ForEach(CardRarity.allCases, id: \.self) { rarity in
                            Text(rarity.rawValue).tag(rarity)
                        }
                    }
                }
                
                Section("Card Stats") {
                    TextField("HP (optional)", text: $hp)
                        .keyboardType(.numberPad)
                    
                    TextField("Market Value (optional)", text: $marketValue)
                        .keyboardType(.decimalPad)
                    
                    TextField("Artist (optional)", text: $artist)
                }
                
                Section("Types") {
                    LazyVGrid(columns: [
                        GridItem(.flexible()),
                        GridItem(.flexible()),
                        GridItem(.flexible())
                    ], spacing: 8) {
                        ForEach(PokemonType.allCases, id: \.self) { type in
                            TypeSelectionButton(
                                type: type,
                                isSelected: selectedTypes.contains(type)
                            ) {
                                if selectedTypes.contains(type) {
                                    selectedTypes.remove(type)
                                } else {
                                    selectedTypes.insert(type)
                                }
                            }
                        }
                    }
                }
                
                Section {
                    Button(action: {
                        addCardManually()
                    }) {
                        HStack {
                            Image(systemName: "plus.circle.fill")
                            Text("Add Card to Collection")
                        }
                        .frame(maxWidth: .infinity)
                    }
                    .disabled(isAdding || cardName.isEmpty || cardSet.isEmpty || cardNumber.isEmpty)
                    
                    if isAdding {
                        HStack(spacing: 8) {
                            ProgressView()
                            Text("Adding card...")
                                .foregroundColor(.secondary)
                                .font(.caption)
                        }
                    }
                }
            }
            .navigationTitle("Add Card Manually")
            .navigationBarTitleDisplayMode(.inline)
            .scrollDismissesKeyboard(.automatic)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        presentationMode.wrappedValue.dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Add") {
                        addCardManually()
                    }
                    .disabled(isAdding || cardName.isEmpty || cardSet.isEmpty || cardNumber.isEmpty)
                }
            }
            .alert("Card Added!", isPresented: $showingSuccess) {
                Button("OK") {
                    presentationMode.wrappedValue.dismiss()
                }
            } message: {
                Text("\(cardName) has been added to your collection!")
            }
        }
    }
    
    private func addCardManually() {
        isAdding = true
        let hpValue = Int(hp.trimmingCharacters(in: .whitespacesAndNewlines)) ?? nil
        let value = parseDecimalString(marketValue)
        let nameInput = cardName.trimmingCharacters(in: .whitespacesAndNewlines)
        let setInput = cardSet.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        let numberInput = cardNumber.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        // Normalize number: keep digits and strip leading zeros so "010" becomes "10"
        let rawDigits = numberInput.filter { $0.isNumber }
        let numberDigits = rawDigits.drop { $0 == "0" }.isEmpty ? rawDigits : String(rawDigits.drop { $0 == "0" })
        
        Task {
            var resolvedImageURL: String? = nil
            let api = PokemonTCGAPIService.shared

            // Helper to pick best image URL from a list of API cards
            func bestImageURL(from cards: [PokemonTCGCard]) -> String? {
                // Filter to cards that actually have an image URL
                let cardsWithImages = cards.filter { !$0.images.large.isEmpty || !$0.images.small.isEmpty }

                // Prefer exact/near number match, then set name contains, then any with image
                let preferred = cardsWithImages.first(where: { numbersEquivalent($0.number, numberDigits) && (setInput.isEmpty || $0.set.name.lowercased().contains(setInput)) })
                    ?? cardsWithImages.first(where: { numbersEquivalent($0.number, numberDigits) })
                    ?? cardsWithImages.first(where: { setInput.isEmpty ? false : $0.set.name.lowercased().contains(setInput) })
                    ?? cardsWithImages.first

                guard let chosen = preferred else { return nil }
                return chosen.images.large.isEmpty ? chosen.images.small : chosen.images.large
            }

            // 1) Try structured search (name + set + number) with retries
            var cards: [PokemonTCGCard] = []
            if let response = await withRetries(maxAttempts: 2, delay: 0.35, { try await api.searchCards(
                name: nameInput,
                setName: setInput.isEmpty ? nil : cardSet,
                number: numberDigits.isEmpty ? nil : numberDigits,
                rarity: selectedRarity == .promo ? "Promo" : nil,
                pageSize: 12
            )}) {
                cards = response.data
            }

            // 2) If none, fallback to name-only fuzzy (preserve promo rarity if selected)
            if cards.isEmpty {
                if selectedRarity == .promo {
                    if let response = await withRetries(maxAttempts: 2, delay: 0.35, { try await api.searchCards(name: nameInput, setName: nil, number: nil, rarity: "Promo", pageSize: 20) }) {
                        cards = response.data
                    }
                }
                if cards.isEmpty {
                    if let response = await withRetries(maxAttempts: 2, delay: 0.35, { try await api.searchCards(query: nameInput, pageSize: 30) }) {
                        cards = response.data
                    }
                }
            }

            resolvedImageURL = bestImageURL(from: cards)
            if resolvedImageURL == nil {
                print("Manual add: No image URL could be resolved for \(nameInput) \(cardNumber)")
            }

            let newCard = PokemonCard(
                name: nameInput,
                set: cardSet,
                number: cardNumber,
                rarity: selectedRarity,
                imageURL: resolvedImageURL,
                hp: hpValue,
                types: Array(selectedTypes),
                artist: artist.isEmpty ? nil : artist,
                marketValue: value
            )

            print("Adding card with imageURL: \(resolvedImageURL ?? "nil")")
            cardCollection.addCard(newCard)
            isAdding = false
            showingSuccess = true
        }
    }

    private func parseDecimalString(_ text: String) -> Double? {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty { return nil }
        let allowed = CharacterSet(charactersIn: "0123456789.")
        let filtered = String(trimmed.unicodeScalars.filter { allowed.contains($0) })
        return Double(filtered)
    }

    private func numbersEquivalent(_ apiNumber: String, _ userDigits: String) -> Bool {
        let trimmed = userDigits.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return false }
        // Extract leading integer from API number (e.g., "10/124" -> "10")
        let leadingApiDigits = String(apiNumber.prefix { $0.isNumber })
        let apiInt = Int(leadingApiDigits) ?? -1
        let userInt = Int(trimmed) ?? -2
        return apiInt == userInt
    }
    
    private func withRetries<T>(maxAttempts: Int = 2, delay: TimeInterval = 0.35, _ op: @escaping () async throws -> T) async -> T? {
        var attempt = 0
        while attempt < maxAttempts {
            do { return try await op() } catch {
                attempt += 1
                if attempt >= maxAttempts { return nil }
                try? await Task.sleep(nanoseconds: UInt64(delay * 1_000_000_000))
            }
        }
        return nil
    }
}

struct TypeSelectionButton: View {
    let type: PokemonType
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 4) {
                Image(systemName: type.icon)
                    .font(.title3)
                    .foregroundColor(isSelected ? .white : type.color)
                
                Text(type.rawValue)
                    .font(.caption2)
                    .fontWeight(.medium)
                    .foregroundColor(isSelected ? .white : .primary)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 8)
            .background(isSelected ? type.color : type.color.opacity(0.1))
            .cornerRadius(8)
        }
        .buttonStyle(PlainButtonStyle())
    }
}

#Preview {
    ManualEntryView()
        .environmentObject(CardCollection())
}

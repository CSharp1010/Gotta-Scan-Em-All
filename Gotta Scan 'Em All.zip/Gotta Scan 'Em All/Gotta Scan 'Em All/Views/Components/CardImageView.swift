//
//  CardImageView.swift
//  Gotta Scan 'Em All
//
//  Created by Jersain Hermosillo on 9/8/25.
//

import SwiftUI
#if canImport(UIKit)
import UIKit
#endif

struct CardImageView: View {
    let card: PokemonCard
    let aspectRatio: CGFloat
    let cornerRadius: CGFloat
    let showPlaceholder: Bool
    
    init(card: PokemonCard, aspectRatio: CGFloat = 0.7, cornerRadius: CGFloat = 8, showPlaceholder: Bool = true) {
        self.card = card
        self.aspectRatio = aspectRatio
        self.cornerRadius = cornerRadius
        self.showPlaceholder = showPlaceholder
    }
    
    var body: some View {
        Group {
            if let imageURL = card.imageURL, !imageURL.isEmpty {
                AsyncImage(url: URL(string: imageURL), transaction: Transaction(animation: nil)) { phase in
                    switch phase {
                    case .success(let image):
                        image
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                    case .failure(let error):
                        CardPlaceholderView(showPlaceholder: showPlaceholder)
                            .onAppear { print("Image loading failed for \(card.name): \(error)") }
                    case .empty:
                        VStack {
                            ProgressView()
                                .scaleEffect(0.8)
                            Text("Loading...")
                                .font(.caption2)
                                .foregroundColor(.secondary)
                        }
                    @unknown default:
                        CardPlaceholderView(showPlaceholder: showPlaceholder)
                    }
                }
            } else if let localPath = card.localImagePath, !localPath.isEmpty {
                // Load local image from Documents directory
                if let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
                    let fileURL = documentsDirectory.appendingPathComponent(localPath)
                    if let imageData = try? Data(contentsOf: fileURL),
                       let uiImage = UIImage(data: imageData) {
                        Image(uiImage: uiImage)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                    } else {
                        CardPlaceholderView(showPlaceholder: showPlaceholder)
                    }
                } else {
                    CardPlaceholderView(showPlaceholder: showPlaceholder)
                }
            } else {
                CardPlaceholderView(showPlaceholder: showPlaceholder)
                    .onAppear { print("No image URL for card: \(card.name)") }
            }
        }
        .aspectRatio(aspectRatio, contentMode: .fit)
        .cornerRadius(cornerRadius)
    }
}

struct CardPlaceholderView: View {
    let showPlaceholder: Bool
    
    var body: some View {
        RoundedRectangle(cornerRadius: 8)
            .fill(Color(.systemGray5))
            .overlay(
                VStack {
                    if showPlaceholder {
                        Image(systemName: "photo")
                            .font(.title)
                            .foregroundColor(.gray)
                        Text("Card Image")
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                }
            )
    }
}

#Preview {
    VStack(spacing: 20) {
        CardImageView(card: PokemonCard(
            name: "Pikachu",
            set: "Base Set",
            number: "58/102",
            rarity: .common,
            imageURL: "https://images.pokemontcg.io/base1/58_hires.png",
            hp: 40,
            types: [.lightning],
            marketValue: 5.99
        ))
        .frame(height: 200)
        
        CardImageView(card: PokemonCard(
            name: "Unknown Card",
            set: "Unknown Set",
            number: "?/?",
            rarity: .common
        ))
        .frame(height: 200)
    }
    .padding()
}

//
//  StatisticsView.swift
//  Gotta Scan 'Em All
//
//  Created by Jersain Hermosillo on 9/8/25.
//

import SwiftUI
import Charts

struct StatisticsView: View {
    @EnvironmentObject var cardCollection: CardCollection
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // Overview Cards
                    LazyVGrid(columns: [
                        GridItem(.flexible()),
                        GridItem(.flexible())
                    ], spacing: 16) {
                        StatCard(
                            title: "Total Cards",
                            value: "\(cardCollection.cards.count)",
                            icon: "square.grid.3x3",
                            color: .blue
                        )
                        
                        StatCard(
                            title: "Collection Value",
                            value: String(format: "$%.2f", cardCollection.totalValue),
                            icon: "dollarsign.circle",
                            color: .green
                        )
                        
                        StatCard(
                            title: "Unique Sets",
                            value: "\(cardCollection.uniqueSets.count)",
                            icon: "folder",
                            color: .orange
                        )
                        
                        StatCard(
                            title: "Avg. Card Value",
                            value: {
                                let valued = cardCollection.cards.compactMap { $0.marketValue }
                                guard !valued.isEmpty else { return "$0.00" }
                                let avg = valued.reduce(0, +) / Double(valued.count)
                                return String(format: "$%.2f", avg)
                            }(),
                            icon: "chart.line.uptrend.xyaxis",
                            color: .purple
                        )
                    }
                    .padding(.horizontal)
                    
                    // Rarity Distribution
                    if !cardCollection.cards.isEmpty {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Rarity Distribution")
                                .font(.headline)
                                .padding(.horizontal)
                            
                            RarityChart(rarityCounts: cardCollection.rarityCounts)
                                .frame(height: 200)
                                .padding(.horizontal)
                        }
                    }
                    
                    // Type Distribution
                    if !cardCollection.cards.isEmpty {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Type Distribution")
                                .font(.headline)
                                .padding(.horizontal)
                            
                            TypeChart(typeCounts: cardCollection.typeCounts)
                                .frame(height: 200)
                                .padding(.horizontal)
                        }
                    }
                    
                    // Recent Additions
                    if !cardCollection.cards.isEmpty {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Recent Additions")
                                .font(.headline)
                                .padding(.horizontal)
                            
                            let recentCards = Array(cardCollection.cards.sorted { $0.dateAdded > $1.dateAdded }.prefix(5))
                            
                            ForEach(recentCards) { card in
                                RecentCardRow(card: card)
                            }
                            .padding(.horizontal)
                        }
                    }
                    
                    // Empty State
                    if cardCollection.cards.isEmpty {
                        VStack(spacing: 20) {
                            Image(systemName: "chart.bar.fill")
                                .font(.system(size: 60))
                                .foregroundColor(.gray)
                            
                            Text("No Statistics Yet")
                                .font(.title2)
                                .fontWeight(.semibold)
                            
                            Text("Add some cards to your collection to see detailed statistics!")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal)
                        }
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .padding(.top, 100)
                    }
                }
                .padding(.vertical)
            }
            .navigationTitle("Statistics")
        }
    }
}

struct StatCard: View {
    let title: String
    let value: String
    let icon: String
    let color: Color
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: icon)
                    .foregroundColor(color)
                Spacer()
            }
            
            Text(value)
                .font(.title2)
                .fontWeight(.bold)
            
            Text(title)
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: 1)
    }
}

struct RarityChart: View {
    let rarityCounts: [CardRarity: Int]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ForEach(CardRarity.allCases, id: \.self) { rarity in
                if let count = rarityCounts[rarity], count > 0 {
                    HStack {
                        Text(rarity.rawValue)
                            .font(.caption)
                            .frame(width: 80, alignment: .leading)
                        
                        GeometryReader { geometry in
                            HStack(spacing: 0) {
                                Rectangle()
                                    .fill(rarity.color)
                                    .frame(width: geometry.size.width * CGFloat(count) / CGFloat(rarityCounts.values.max() ?? 1))
                                
                                Spacer()
                            }
                        }
                        .frame(height: 20)
                        .background(Color(.systemGray5))
                        .cornerRadius(4)
                        
                        Text("\(count)")
                            .font(.caption)
                            .fontWeight(.medium)
                            .frame(width: 30, alignment: .trailing)
                    }
                }
            }
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: 1)
    }
}

struct TypeChart: View {
    let typeCounts: [PokemonType: Int]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ForEach(PokemonType.allCases, id: \.self) { type in
                if let count = typeCounts[type], count > 0 {
                    HStack {
                        HStack(spacing: 4) {
                            Image(systemName: type.icon)
                                .foregroundColor(type.color)
                            Text(type.rawValue)
                        }
                        .font(.caption)
                        .frame(width: 80, alignment: .leading)
                        
                        GeometryReader { geometry in
                            HStack(spacing: 0) {
                                Rectangle()
                                    .fill(type.color)
                                    .frame(width: geometry.size.width * CGFloat(count) / CGFloat(typeCounts.values.max() ?? 1))
                                
                                Spacer()
                            }
                        }
                        .frame(height: 20)
                        .background(Color(.systemGray5))
                        .cornerRadius(4)
                        
                        Text("\(count)")
                            .font(.caption)
                            .fontWeight(.medium)
                            .frame(width: 30, alignment: .trailing)
                    }
                }
            }
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: 1)
    }
}

struct RecentCardRow: View {
    let card: PokemonCard
    
    var body: some View {
        HStack {
            // Card image
            CardImageView(card: card, aspectRatio: 0.7, cornerRadius: 6, showPlaceholder: false)
                .frame(width: 40, height: 56)
            
            VStack(alignment: .leading, spacing: 2) {
                Text(card.name)
                    .font(.headline)
                    .lineLimit(1)
                
                Text(card.set)
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                Text("Added \(card.dateAdded, style: .relative)")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            RarityBadge(rarity: card.rarity)
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(8)
        .shadow(color: .black.opacity(0.05), radius: 1, x: 0, y: 1)
    }
}

#Preview {
    StatisticsView()
        .environmentObject(CardCollection())
}

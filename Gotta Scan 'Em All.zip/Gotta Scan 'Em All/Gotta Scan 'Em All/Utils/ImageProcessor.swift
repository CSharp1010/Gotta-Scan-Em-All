//
//  ImageProcessor.swift
//  Gotta Scan 'Em All
//
//  Created by Jersain Hermosillo on 9/8/25.
//

import Foundation
import Combine
import CoreImage
import Vision

#if canImport(UIKit)
import UIKit
public typealias XImage = UIImage
#elseif canImport(AppKit)
import AppKit
public typealias XImage = NSImage
#endif

class ImageProcessor: ObservableObject {
    @Published var processedImage: XImage?
    @Published var isProcessing = false
    
    private let ciContext = CIContext(options: nil)
    private let processingQueue = DispatchQueue(label: "com.gottaScan.imageprocessing", qos: .userInitiated)
    private lazy var rectangleRequest: VNDetectRectanglesRequest = {
        let request = VNDetectRectanglesRequest()
        request.minimumAspectRatio = 0.5
        request.maximumAspectRatio = 0.8
        request.minimumSize = 0.1
        request.maximumObservations = 1
        return request
    }()
    private var isCancelled = false
    private let cancellationLock = NSLock()
    
    func processCardImage(_ image: XImage, completion: @escaping (XImage?) -> Void) {
        cancellationLock.lock()
        isCancelled = false
        cancellationLock.unlock()
        isProcessing = true

        processingQueue.async { [weak self] in
            guard let self = self else { return }
            self.cancellationLock.lock()
            let cancelledEarly = self.isCancelled
            self.cancellationLock.unlock()
            if cancelledEarly {
                DispatchQueue.main.async { [weak self] in
                    guard let self = self else { return }
                    self.isProcessing = false
                    completion(nil)
                }
                return
            }
            // First, try to detect and crop the card
            let croppedImage = self.detectAndCropCard(in: image) ?? image

            self.cancellationLock.lock()
            let cancelledAfterCrop = self.isCancelled
            self.cancellationLock.unlock()
            if cancelledAfterCrop {
                DispatchQueue.main.async { [weak self] in
                    guard let self = self else { return }
                    self.isProcessing = false
                    completion(nil)
                }
                return
            }
            // Then enhance the image
            let enhancedImage = self.enhanceImage(croppedImage)

            self.cancellationLock.lock()
            let cancelledAfterEnhance = self.isCancelled
            self.cancellationLock.unlock()
            if cancelledAfterEnhance {
                DispatchQueue.main.async { [weak self] in
                    guard let self = self else { return }
                    self.isProcessing = false
                    completion(nil)
                }
                return
            }

            DispatchQueue.main.async { [weak self] in
                guard let self = self else { return }
                self.isProcessing = false
                self.processedImage = enhancedImage
                completion(enhancedImage)
            }
        }
    }
    
    func cancelProcessing() {
        cancellationLock.lock()
        isCancelled = true
        cancellationLock.unlock()
    }
    
    private func detectAndCropCard(in image: XImage) -> XImage? {
        guard let cg = makeCGImage(from: image) else { return nil }

        cancellationLock.lock()
        if isCancelled { cancellationLock.unlock(); return nil }
        cancellationLock.unlock()

        // Configure request handler and perform detection
        let handler = VNImageRequestHandler(cgImage: cg, options: [:])
        do {
            try handler.perform([rectangleRequest])
            if let observation = rectangleRequest.results?.first as? VNRectangleObservation {
                cancellationLock.lock()
                if isCancelled { cancellationLock.unlock(); return nil }
                cancellationLock.unlock()
                return cropImage(image, to: observation)
            }
        } catch {
            print("Rectangle detection failed: \(error)")
        }
        return nil
    }
    
    private func cropImage(_ image: XImage, to observation: VNRectangleObservation) -> XImage? {
        let imageSize = image.size
        
        // Convert normalized coordinates to image coordinates
        let topLeft = CGPoint(
            x: observation.topLeft.x * imageSize.width,
            y: (1 - observation.topLeft.y) * imageSize.height
        )
        let topRight = CGPoint(
            x: observation.topRight.x * imageSize.width,
            y: (1 - observation.topRight.y) * imageSize.height
        )
        let bottomLeft = CGPoint(
            x: observation.bottomLeft.x * imageSize.width,
            y: (1 - observation.bottomLeft.y) * imageSize.height
        )
        let bottomRight = CGPoint(
            x: observation.bottomRight.x * imageSize.width,
            y: (1 - observation.bottomRight.y) * imageSize.height
        )
        
        // Create a perspective correction transform
        guard let perspectiveTransform = CIFilter(name: "CIPerspectiveCorrection") else {
            return image
        }
        perspectiveTransform.setValue(CIImage(image: image), forKey: kCIInputImageKey)
        perspectiveTransform.setValue(CIVector(cgPoint: topLeft), forKey: "inputTopLeft")
        perspectiveTransform.setValue(CIVector(cgPoint: topRight), forKey: "inputTopRight")
        perspectiveTransform.setValue(CIVector(cgPoint: bottomLeft), forKey: "inputBottomLeft")
        perspectiveTransform.setValue(CIVector(cgPoint: bottomRight), forKey: "inputBottomRight")
        
        guard let outputImage = perspectiveTransform.outputImage else { return nil }
        
        let context = ciContext
        guard let cgImage = context.createCGImage(outputImage, from: outputImage.extent) else { return nil }
        
#if canImport(UIKit)
        return UIImage(cgImage: cgImage)
#else
        return NSImage(cgImage: cgImage, size: .zero)
#endif
    }
    
    private func enhanceImage(_ image: XImage) -> XImage? {
        guard let cg = makeCGImage(from: image) else { return nil }
        let ci = CIImage(cgImage: cg)

        cancellationLock.lock()
        if isCancelled { cancellationLock.unlock(); return nil }
        cancellationLock.unlock()

        let context = ciContext
        guard let filter = CIFilter(name: "CIColorControls") else { return image }
        filter.setValue(ci, forKey: kCIInputImageKey)
        filter.setValue(1.2, forKey: kCIInputContrastKey)
        filter.setValue(0.1, forKey: kCIInputBrightnessKey)
        filter.setValue(1.1, forKey: kCIInputSaturationKey)

        guard let output = filter.outputImage,
              let enhanced = context.createCGImage(output, from: output.extent) else {
            return image
        }

    #if canImport(UIKit)
        return UIImage(cgImage: enhanced)
    #else
        return NSImage(cgImage: enhanced, size: .zero)
    #endif
    }
    
    func resizeImage(_ image: XImage, to size: CGSize) -> XImage? {
#if canImport(UIKit)
        UIGraphicsBeginImageContextWithOptions(size, false, 0.0)
        image.draw(in: CGRect(origin: .zero, size: size))
        let resizedImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return resizedImage
#else
        let newImage = NSImage(size: size)
        newImage.lockFocus()
        image.draw(in: CGRect(origin: .zero, size: size))
        newImage.unlockFocus()
        return newImage
#endif
    }
    
    private func makeCGImage(from image: XImage) -> CGImage? {
    #if canImport(UIKit)
        return image.cgImage
    #else
        var rect = CGRect(origin: .zero, size: image.size)
        return image.cgImage(forProposedRect: &rect, context: nil, hints: nil)
    #endif
    }
}


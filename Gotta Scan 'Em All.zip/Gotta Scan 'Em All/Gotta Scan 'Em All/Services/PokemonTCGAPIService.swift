//
//  PokemonTCGAPIService.swift
//  Gotta Scan 'Em All
//
//  Created by Jersain Hermosillo on 9/8/25.
//

import Foundation
import SwiftUI

class PokemonTCGAPIService: ObservableObject {
    static let shared = PokemonTCGAPIService()
    
    private let baseURL = "https://api.pokemontcg.io/v2"
    private let session = URLSession.shared
    
    private init() {}
    
    // MARK: - Card Search
    
    func searchCards(query: String, page: Int = 1, pageSize: Int = 20) async throws -> PokemonTCGResponse {
        let encodedQuery = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        let urlString = "\(baseURL)/cards?q=name:*\(encodedQuery)*&page=\(page)&pageSize=\(pageSize)"
        
        guard let url = URL(string: urlString) else {
            throw APIError.invalidURL
        }
        
        let (data, response) = try await session.data(from: url)
        
        guard let httpResponse = response as? HTTPURLResponse,
              httpResponse.statusCode == 200 else {
            throw APIError.invalidResponse
        }
        
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try decoder.decode(PokemonTCGResponse.self, from: data)
    }
    
    // Exact/filtered search helper using API query syntax
    func searchCards(name: String?, setName: String?, number: String?, rarity: String? = nil, page: Int = 1, pageSize: Int = 20) async throws -> PokemonTCGResponse {
        var clauses: [String] = []
        if let name = name?.trimmingCharacters(in: .whitespacesAndNewlines), !name.isEmpty {
            let escaped = name.replacingOccurrences(of: "\"", with: "\\\"")
            clauses.append("name:\"\(escaped)\"")
        }
        if let setName = setName?.trimmingCharacters(in: .whitespacesAndNewlines), !setName.isEmpty {
            let escaped = setName.replacingOccurrences(of: "\"", with: "\\\"")
            // use contains wildcard to improve matching when the user input isn't exact
            clauses.append("set.name:*\(escaped)*")
        }
        if let number = number?.trimmingCharacters(in: .whitespacesAndNewlines), !number.isEmpty {
            // Normalize to digits only (so "010" matches "10/124") and use wildcard
            let digits = number.filter { $0.isNumber }
            if !digits.isEmpty {
                clauses.append("number:*\(digits)*")
            }
        }
        if let rarity = rarity?.trimmingCharacters(in: .whitespacesAndNewlines), !rarity.isEmpty {
            let escaped = rarity.replacingOccurrences(of: "\"", with: "\\\"")
            clauses.append("rarity:*\(escaped)*")
        }
        // Prefer Pokémon supertype to avoid trainer/energy collisions
        clauses.append("supertype:Pokémon")
        let q = clauses.joined(separator: " ")
        let encodedQ = q.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        let urlString = "\(baseURL)/cards?q=\(encodedQ)&page=\(page)&pageSize=\(pageSize)"
        guard let url = URL(string: urlString) else { throw APIError.invalidURL }
        let (data, response) = try await session.data(from: url)
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else { throw APIError.invalidResponse }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try decoder.decode(PokemonTCGResponse.self, from: data)
    }
    
    func getCard(by id: String) async throws -> PokemonTCGCard {
        let urlString = "\(baseURL)/cards/\(id)"
        
        guard let url = URL(string: urlString) else {
            throw APIError.invalidURL
        }
        
        let (data, response) = try await session.data(from: url)
        
        guard let httpResponse = response as? HTTPURLResponse,
              httpResponse.statusCode == 200 else {
            throw APIError.invalidResponse
        }
        
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        let cardResponse = try decoder.decode(PokemonTCGCardResponse.self, from: data)
        return cardResponse.data
    }
    
    // MARK: - Sets
    
    func getSets() async throws -> PokemonTCGSetsResponse {
        let urlString = "\(baseURL)/sets"
        
        guard let url = URL(string: urlString) else {
            throw APIError.invalidURL
        }
        
        let (data, response) = try await session.data(from: url)
        
        guard let httpResponse = response as? HTTPURLResponse,
              httpResponse.statusCode == 200 else {
            throw APIError.invalidResponse
        }
        
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try decoder.decode(PokemonTCGSetsResponse.self, from: data)
    }
    
    // MARK: - Convert API Card to App Card
    
    func convertToPokemonCard(_ apiCard: PokemonTCGCard) -> PokemonCard {
        // Map rarity
        let rarity: CardRarity
        switch apiCard.rarity?.lowercased() {
        case "common": rarity = .common
        case "uncommon": rarity = .uncommon
        case "rare": rarity = .rare
        case "rare holo", "rare holofoil": rarity = .rareHolo
        case "ultra rare", "ultra rare holofoil", "double rare": rarity = .ultraRare
        case "secret rare", "hyper rare": rarity = .secretRare
        case "promo": rarity = .promo
        default:
            if let r = apiCard.rarity?.lowercased(), r.contains("illustration") {
                rarity = .illustration
            } else {
                rarity = .common
            }
        }
        
        // Map types
        let types: [PokemonType] = apiCard.types?.compactMap { typeString in
            PokemonType(rawValue: typeString.capitalized)
        } ?? []
        
        // Parse HP
        let hp: Int? = apiCard.hp.flatMap { Int($0) }
        
        // Parse market value (if available from TCGPlayer)
        let marketValue: Double? = apiCard.tcgplayer?.prices?.holofoil?.market ?? 
                                 apiCard.tcgplayer?.prices?.normal?.market ?? 
                                 apiCard.tcgplayer?.prices?.reverseHolofoil?.market
        
        // Parse attacks
        let attacks: [Attack]? = apiCard.attacks?.map { attack in
            let cost = attack.cost?.compactMap { PokemonType(rawValue: $0.capitalized) } ?? []
            return Attack(
                name: attack.name,
                cost: cost,
                damage: attack.damage,
                text: attack.text
            )
        }
        
        // Parse weaknesses
        let weaknesses: [Weakness]? = apiCard.weaknesses?.map { weakness in
            Weakness(
                type: PokemonType(rawValue: weakness.type.capitalized) ?? .colorless,
                value: weakness.value
            )
        }
        
        // Parse resistances
        let resistances: [Resistance]? = apiCard.resistances?.map { resistance in
            Resistance(
                type: PokemonType(rawValue: resistance.type.capitalized) ?? .colorless,
                value: resistance.value
            )
        }
        
        // Prefer large image; fallback to small if large is unavailable
        let chosenImageURL = apiCard.images.large.isEmpty ? apiCard.images.small : apiCard.images.large
        
        return PokemonCard(
            name: apiCard.name,
            set: apiCard.set.name,
            number: apiCard.number,
            rarity: rarity,
            imageURL: chosenImageURL,
            localImagePath: nil,
            hp: hp,
            types: types,
            attacks: attacks,
            weaknesses: weaknesses,
            resistances: resistances,
            retreatCost: apiCard.convertedRetreatCost,
            artist: apiCard.artist,
            marketValue: marketValue
        )
    }
}

// MARK: - API Models

struct PokemonTCGResponse: Codable {
    let data: [PokemonTCGCard]
    let page: Int
    let pageSize: Int
    let count: Int
    let totalCount: Int
}

struct PokemonTCGCardResponse: Codable {
    let data: PokemonTCGCard
}

struct PokemonTCGSetsResponse: Codable {
    let data: [PokemonTCGSet]
}

struct PokemonTCGCard: Codable {
    let id: String
    let name: String
    let supertype: String?
    let subtypes: [String]?
    let level: String?
    let hp: String?
    let types: [String]?
    let evolvesFrom: String?
    let evolvesTo: [String]?
    let rules: [String]?
    let ancientTrait: AncientTrait?
    let abilities: [Ability]?
    let attacks: [APIAttack]?
    let weaknesses: [APIWeakness]?
    let resistances: [APIResistance]?
    let retreatCost: [String]?
    let convertedRetreatCost: Int?
    let set: PokemonTCGSet
    let number: String
    let artist: String?
    let rarity: String?
    let flavorText: String?
    let nationalPokedexNumbers: [Int]?
    let legalities: Legalities?
    let regulationMark: String?
    let images: CardImages
    let tcgplayer: TCGPlayer?
    let cardmarket: CardMarket?
}

struct PokemonTCGSet: Codable {
    let id: String
    let name: String
    let series: String
    let printedTotal: Int?
    let total: Int
    let legalities: Legalities?
    let ptcgoCode: String?
    let releaseDate: String?
    let updatedAt: String
    let images: SetImages
}

struct AncientTrait: Codable {
    let name: String
    let text: String
}

struct Ability: Codable {
    let name: String
    let text: String
    let type: String
}

struct APIAttack: Codable {
    let name: String
    let cost: [String]?
    let convertedEnergyCost: Int?
    let damage: String?
    let text: String?
}

struct APIWeakness: Codable {
    let type: String
    let value: String
}

struct APIResistance: Codable {
    let type: String
    let value: String
}

struct Legalities: Codable {
    let unlimited: String?
    let standard: String?
    let expanded: String?
}

struct CardImages: Codable {
    let small: String
    let large: String
}

struct SetImages: Codable {
    let symbol: String
    let logo: String
}

struct TCGPlayer: Codable {
    let url: String?
    let updatedAt: String?
    let prices: TCGPlayerPrices?
}

struct TCGPlayerPrices: Codable {
    let holofoil: TCGPlayerPrice?
    let normal: TCGPlayerPrice?
    let reverseHolofoil: TCGPlayerPrice?
    let firstEditionHolofoil: TCGPlayerPrice?
    let firstEditionNormal: TCGPlayerPrice?
    let unlimitedHolofoil: TCGPlayerPrice?
    let unlimitedNormal: TCGPlayerPrice?
}

struct TCGPlayerPrice: Codable {
    let low: Double?
    let mid: Double?
    let high: Double?
    let market: Double?
    let directLow: Double?
}

struct CardMarket: Codable {
    let url: String?
    let updatedAt: String?
    let prices: CardMarketPrices?
}

struct CardMarketPrices: Codable {
    let averageSellPrice: Double?
    let lowPrice: Double?
    let trendPrice: Double?
    let germanProLow: Double?
    let suggestedPrice: Double?
    let reverseHoloSell: Double?
    let reverseHoloLow: Double?
    let reverseHoloTrend: Double?
    let lowPriceExPlus: Double?
    let avg1: Double?
    let avg7: Double?
    let avg30: Double?
    let reverseHoloAvg1: Double?
    let reverseHoloAvg7: Double?
    let reverseHoloAvg30: Double?
}

// MARK: - Errors

enum APIError: Error, LocalizedError {
    case invalidURL
    case invalidResponse
    case noData
    case decodingError
    
    var errorDescription: String? {
        switch self {
        case .invalidURL:
            return "Invalid URL"
        case .invalidResponse:
            return "Invalid response from server"
        case .noData:
            return "No data received"
        case .decodingError:
            return "Failed to decode response"
        }
    }
}

extension PokemonTCGAPIService: PokemonCardSearching {
    func searchCards(query: String, pageSize: Int) async throws -> PokemonCardSearchResult {
        let response = try await self.searchCards(query: query, page: 1, pageSize: pageSize)
        return PokemonCardSearchResult(rawCards: response.data)
    }

    func convertToPokemonCard(_ apiCard: Any) -> PokemonCard? {
        guard let card = apiCard as? PokemonTCGCard else { return nil }
        return self.convertToPokemonCard(card)
    }
}

//
//  CardRecognitionService.swift
//  Gotta Scan 'Em All
//
//  Created by Jersain Hermosillo on 9/8/25.
//

import Foundation
import Vision
import SwiftUI

struct PokemonCardSearchResult {
    let rawCards: [Any]
    // Backward compatibility: some call sites still expect `data` as `[PokemonTCGCard]`
    var data: [PokemonTCGCard] { rawCards as? [PokemonTCGCard] ?? [] }
}

// MARK: - Protocols for Dependency Injection
protocol PokemonCardSearching {
    func searchCards(query: String, pageSize: Int) async throws -> PokemonCardSearchResult
    func convertToPokemonCard(_ apiCard: Any) -> PokemonCard?
}

// If your existing PokemonTCGAPIService already has these signatures, you can add conformance in that file.
// Example extension (adjust types as needed):
// extension PokemonTCGAPIService: PokemonCardSearching {}

// MARK: - Main Service
@MainActor
final class CardRecognitionService: ObservableObject {
    @Published var isRecognizing = false
    @Published private(set) var isResolving: Bool = false
    @Published var recognitionResult: CardRecognitionResult?
    @Published var lastError: Error?

    private var recognitionTask: Task<Void, Never>?

    // Keep a type-erased wrapper so we can store any conformer without exposing associated types here.
    private let _searchCards: (String, Int) async throws -> PokemonCardSearchResult
    private let _convert: (Any) -> PokemonCard?

    // Convenience initializer for your concrete API service
    init(apiService: any PokemonCardSearching) {
        self._searchCards = { query, pageSize in
            try await apiService.searchCards(query: query, pageSize: pageSize)
        }
        self._convert = { anyCard in
            return apiService.convertToPokemonCard(anyCard)
        }
    }

    struct CardRecognitionResult: Equatable, Codable {
        let confidence: Float
        let suggestedCard: PokemonCard?
        let detectedText: [String]
    }

    @MainActor
    private func beginResolving() {
        isResolving = true
    }

    @MainActor
    private func endResolving() {
        isResolving = false
    }

    // MARK: - Public API
    func recognizeCard(from image: UIImage, completion: @escaping (CardRecognitionResult?) -> Void) {
        // Cancel any in-flight recognition
        recognitionTask?.cancel()
        lastError = nil
        isRecognizing = true

        recognitionTask = Task { [weak self] in
            guard let self else {
                print("❌ CardRecognitionService deallocated")
                DispatchQueue.main.async {
                    completion(nil)
                }
                return
            }
            // Begin resolving on main before starting heavy work
            await MainActor.run {
                self.beginResolving()
            }

            let result = await self.performRecognition(on: image)
            
            // Always call completion, even if cancelled
            await MainActor.run {
                self.isRecognizing = false
                if !Task.isCancelled {
                    self.recognitionResult = result
                }
                self.endResolving()
                print("📤 Calling completion with result: \(result != nil ? "found" : "nil")")
                completion(result)
            }
        }
    }

    // MARK: - Pipeline
    private func performRecognition(on image: UIImage) async -> CardRecognitionResult? {
        print("📸 Step 0: Downscaling image...")
        // Step 0: Downscale for performance (non-blocking)
        let cgImage = downscaledCGImage(from: image, maxDimension: 1280) ?? image.cgImage
        guard let cgImage else {
            print("❌ Failed to get CGImage")
            return CardRecognitionResult(confidence: 0, suggestedCard: nil, detectedText: [])
        }
        print("✅ Image downscaled: \(cgImage.width)x\(cgImage.height)")

        print("🔤 Step 1: Extracting text from image...")
        // Step 1: Extract text from the image (async)
        let detectedText = await extractText(from: cgImage)
        print("📝 Detected \(detectedText.count) text lines: \(detectedText.prefix(3).joined(separator: ", "))")
        
        // If no text detected, return early with empty result
        if detectedText.isEmpty {
            print("⚠️ No text detected in image")
            return CardRecognitionResult(confidence: 0, suggestedCard: nil, detectedText: [])
        }

        print("🔍 Step 2: Identifying best card candidate...")
        // Step 2: Identify the best card candidate
        let identification = await identifyBestCard(from: detectedText)
        print("🎯 Best match: \(identification.card?.name ?? "none"), score: \(identification.matchScore)")

        // Step 3: Calculate confidence (includes match score)
        let confidence = calculateConfidence(from: detectedText, matchScore: identification.matchScore)
        print("📊 Confidence: \(confidence)")

        let result = CardRecognitionResult(
            confidence: confidence,
            suggestedCard: identification.card,
            detectedText: detectedText
        )
        print("✅ Recognition complete: \(result.suggestedCard != nil ? "card found" : "no card")")
        return result
    }

    // MARK: - Vision OCR (Async)
    private func extractText(from cgImage: CGImage) async -> [String] {
        print("🔍 Starting Vision text recognition...")
        return await withCheckedContinuation { continuation in
            let request = VNRecognizeTextRequest { request, error in
                if let error = error {
                    print("❌ Vision error: \(error.localizedDescription)")
                    continuation.resume(returning: [])
                    return
                }
                
                guard let observations = request.results as? [VNRecognizedTextObservation] else {
                    print("⚠️ No text observations found")
                    continuation.resume(returning: [])
                    return
                }
                
                let lines = observations.compactMap { observation -> String? in
                    observation.topCandidates(1).first?.string
                }
                print("✅ Vision found \(lines.count) text lines")
                continuation.resume(returning: lines)
            }
            request.recognitionLevel = .accurate
            request.usesLanguageCorrection = true

            DispatchQueue.global(qos: .userInitiated).async { [weak self] in
                let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
                do {
                    try handler.perform([request])
                } catch {
                    print("❌ Vision handler error: \(error.localizedDescription)")
                    Task { @MainActor in
                        self?.lastError = error
                    }
                    continuation.resume(returning: [])
                }
            }
        }
    }

    // MARK: - Identification
    private struct IdentificationResult {
        let card: PokemonCard?
        let matchScore: Int
    }

    private func identifyBestCard(from text: [String]) async -> IdentificationResult {
        let fullText = text.joined(separator: " ").lowercased()
        let names = Array(uniqueOrdered(extractPokemonNames(from: fullText))).prefix(3) // Reduced from 5 to 3
        print("🔎 Extracted names: \(names)")

        var candidates: [PokemonCard] = []

        // Query by top extracted names (stop early if we find good candidates)
        for name in names {
            print("🌐 Searching API for: \(name)")
            if let result = await withRetries(maxAttempts: 1, delay: 0.2, operation: { [self] in 
                try await self._searchCards(String(name), 10) // Increased page size to get more results in one call
            }) {
                let converted = result.rawCards.compactMap { _convert($0) }
                print("✅ Found \(converted.count) candidates for \(name)")
                candidates.append(contentsOf: converted)
                
                // If we found good candidates, we can stop searching
                if converted.count >= 3 {
                    print("✅ Found enough candidates, stopping search")
                    break
                }
            } else {
                print("⚠️ API search failed for \(name)")
                Task { @MainActor in self.lastError = APIError.invalidResponse }
            }
        }

        // Fallback: query by full text (only if we have very few candidates)
        if candidates.count < 2, !fullText.isEmpty {
            print("🔄 Fallback: Searching with full text: \(fullText.prefix(50))")
            if let result = await withRetries(maxAttempts: 1, delay: 0.2, operation: { [self] in 
                try await self._searchCards(fullText, 10) 
            }) {
                let converted = result.rawCards.compactMap { _convert($0) }
                print("✅ Found \(converted.count) candidates from full text")
                candidates.append(contentsOf: converted)
            } else {
                print("⚠️ Full text search also failed")
                Task { @MainActor in self.lastError = APIError.invalidResponse }
            }
        }

        guard !candidates.isEmpty else { 
            print("❌ No candidates found")
            return IdentificationResult(card: nil, matchScore: 0) 
        }

        // Score candidates
        func score(card: PokemonCard) -> Int {
            var s = 0
            let lower = fullText

            let cardName = card.name.lowercased()
            let cardSet = card.set.lowercased()
            let cardNumber = card.number.lowercased()

            // Exact name match gets highest score
            if !cardName.isEmpty {
                if lower.contains(cardName) {
                    s += 5
                    // Bonus for exact match (handles "Lucario GX" matching "Lucario")
                    if lower.contains("\(cardName) gx") || lower.contains("gx \(cardName)") {
                        s += 3 // Extra points for GX cards
                    }
                }
                // Partial match (e.g., "Lucario GX" contains "lucario")
                let nameWords = cardName.split(separator: " ")
                for word in nameWords where word.count > 3 {
                    if lower.contains(String(word)) {
                        s += 2
                    }
                }
            }
            
            if !cardSet.isEmpty, lower.contains(cardSet) { s += 3 }

            // Number matching: compare digits-only to account for formats like "10/124"
            let digitsInText = lower.filter { $0.isNumber }
            let digitsInCard = cardNumber.filter { $0.isNumber }
            if !digitsInCard.isEmpty, digitsInText.contains(digitsInCard) { s += 2 }

            // HP matching - look for HP values in text
            if let hp = card.hp {
                if lower.contains("\(hp) hp") || lower.contains("hp \(hp)") {
                    s += 2
                }
            }
            
            if lower.contains("hp") { s += 1 }
            return s
        }

        let best = candidates.max(by: { score(card: $0) < score(card: $1) })
        let bestScore = best.map(score) ?? 0
        print("🏆 Best card scored \(bestScore) points: \(best?.name ?? "none")")
        return IdentificationResult(card: best, matchScore: bestScore)
    }

    // MARK: - Name Extraction Heuristics
    private func extractPokemonNames(from text: String) -> [String] {
        let commonPokemon: Set<String> = [
            "pikachu","charizard","blastoise","venusaur","mewtwo","alakazam",
            "machamp","gyarados","dragonite","mew","lugia","ho-oh","celebi",
            "rayquaza","groudon","kyogre","jirachi","deoxys","lucario",
            "garchomp","dialga","palkia","giratina","arceus","reshiram",
            "zekrom","kyurem","xerneas","yveltal","zygarde","solgaleo",
            "lunala","necrozma","zacian","zamazenta","eternatus"
        ]

        let tokens = text
            .replacingOccurrences(of: "[^A-Za-z0-9\\-\\s]", with: " ", options: .regularExpression)
            .split(separator: " ")
            .map { String($0).lowercased() }

        var candidates = Set(tokens.filter { token in
            commonPokemon.contains(token) || (token.count >= 4 && token.range(of: "[0-9]", options: .regularExpression) == nil)
        })

        let prioritized = tokens.filter { commonPokemon.contains($0) }
        let others = candidates.subtracting(prioritized)
        return Array(prioritized) + Array(others)
    }

    // MARK: - Confidence Calculation
    private func calculateConfidence(from text: [String], matchScore: Int) -> Float {
        let textCount = Float(text.count)
        let lowerJoined = text.joined(separator: " ").lowercased()
        let hasKnownName = ["pikachu","charizard","blastoise","venusaur"].contains { lowerJoined.contains($0) }
        let hasNumbers = text.contains { $0.rangeOfCharacter(from: .decimalDigits) != nil }

        var confidence: Float = 0
        confidence += min(textCount / 20.0, 0.4)
        if hasKnownName { confidence += 0.25 }
        if hasNumbers { confidence += 0.15 }
        confidence += min(Float(matchScore) / 10.0, 0.2)

        return min(max(confidence, 0), 1)
    }

    // MARK: - Utilities
    private func downscaledCGImage(from image: UIImage, maxDimension: CGFloat = 1280) -> CGImage? {
        guard let cg = image.cgImage else { return nil }
        let width = CGFloat(cg.width)
        let height = CGFloat(cg.height)
        let scale = min(1, maxDimension / max(width, height))
        guard scale < 1 else { return cg }

        let newW = Int(width * scale)
        let newH = Int(height * scale)
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        guard let ctx = CGContext(
            data: nil,
            width: newW,
            height: newH,
            bitsPerComponent: 8,
            bytesPerRow: 0,
            space: colorSpace,
            bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
        ) else { return cg }

        ctx.interpolationQuality = .high
        ctx.draw(cg, in: CGRect(x: 0, y: 0, width: newW, height: newH))
        return ctx.makeImage()
    }

    private func uniqueOrdered<S: Sequence>(_ seq: S) -> [S.Element] where S.Element: Hashable {
        var seen = Set<S.Element>()
        var result: [S.Element] = []
        for e in seq {
            if seen.insert(e).inserted { result.append(e) }
        }
        return result
    }

    private func withRetries<T>(maxAttempts: Int = 2, delay: TimeInterval = 0.4, operation: @escaping () async throws -> T) async -> T? {
        var attempt = 0
        while attempt < maxAttempts {
            do { return try await operation() } catch {
                attempt += 1
                if attempt >= maxAttempts { return nil }
                try? await Task.sleep(nanoseconds: UInt64(delay * 1_000_000_000))
            }
        }
        return nil
    }
}


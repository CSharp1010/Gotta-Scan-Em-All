//
//  PokemonCard.swift
//  Gotta Scan 'Em All
//
//  Created by Jersain Hermosillo on 9/8/25.
//

import Foundation
import SwiftUI

struct PokemonCard: Identifiable, Codable, Hashable {
    let id = UUID()
    let name: String
    let set: String
    let number: String
    let rarity: CardRarity
    let imageURL: String?
    let localImagePath: String?
    let hp: Int?
    let types: [PokemonType]
    let attacks: [Attack]?
    let weaknesses: [Weakness]?
    let resistances: [Resistance]?
    let retreatCost: Int?
    let artist: String?
    let dateAdded: Date
    let marketValue: Double?
    
    init(name: String, set: String, number: String, rarity: CardRarity, 
         imageURL: String? = nil, localImagePath: String? = nil,
         hp: Int? = nil, types: [PokemonType] = [], attacks: [Attack]? = nil,
         weaknesses: [Weakness]? = nil, resistances: [Resistance]? = nil,
         retreatCost: Int? = nil, artist: String? = nil, marketValue: Double? = nil) {
        self.name = name
        self.set = set
        self.number = number
        self.rarity = rarity
        self.imageURL = imageURL
        self.localImagePath = localImagePath
        self.hp = hp
        self.types = types
        self.attacks = attacks
        self.weaknesses = weaknesses
        self.resistances = resistances
        self.retreatCost = retreatCost
        self.artist = artist
        self.dateAdded = Date()
        self.marketValue = marketValue
    }
}

enum CardRarity: String, CaseIterable, Codable {
    case common = "Common"
    case uncommon = "Uncommon"
    case rare = "Rare"
    case rareHolo = "Rare Holo"
    case ultraRare = "Ultra Rare"
    case secretRare = "Secret Rare"
    case promo = "Promo"
    case illustration = "Illustration"
    
    var color: Color {
        switch self {
        case .common: return .gray
        case .uncommon: return .green
        case .rare: return .blue
        case .rareHolo: return .purple
        case .ultraRare: return .orange
        case .secretRare: return .red
        case .promo: return .yellow
        case .illustration: return .teal
        }
    }
}

enum PokemonType: String, CaseIterable, Codable {
    case grass = "Grass"
    case fire = "Fire"
    case water = "Water"
    case lightning = "Lightning"
    case psychic = "Psychic"
    case fighting = "Fighting"
    case darkness = "Darkness"
    case metal = "Metal"
    case fairy = "Fairy"
    case dragon = "Dragon"
    case colorless = "Colorless"
    
    var color: Color {
        switch self {
        case .grass: return .green
        case .fire: return .red
        case .water: return .blue
        case .lightning: return .yellow
        case .psychic: return .purple
        case .fighting: return .brown
        case .darkness: return .black
        case .metal: return .gray
        case .fairy: return .pink
        case .dragon: return .indigo
        case .colorless: return .gray
        }
    }
    
    var icon: String {
        switch self {
        case .grass: return "leaf.fill"
        case .fire: return "flame.fill"
        case .water: return "drop.fill"
        case .lightning: return "bolt.fill"
        case .psychic: return "brain.head.profile"
        case .fighting: return "figure.walk"
        case .darkness: return "moon.fill"
        case .metal: return "gear"
        case .fairy: return "sparkles"
        case .dragon: return "star.circle"
        case .colorless: return "circle.fill"
        }
    }
}

struct Attack: Codable, Hashable {
    let name: String
    let cost: [PokemonType]
    let damage: String?
    let text: String?
}

struct Weakness: Codable, Hashable {
    let type: PokemonType
    let value: String
}

struct Resistance: Codable, Hashable {
    let type: PokemonType
    let value: String
}

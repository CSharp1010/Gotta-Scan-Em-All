//
//  CardCollection.swift
//  Gotta Scan 'Em All
//
//  Created by Jersain Hermosillo on 9/8/25.
//

import Foundation

class CardCollection: ObservableObject {
    @Published var cards: [PokemonCard] = []
    @Published var totalValue: Double = 0.0
    
    init() {
        loadCards()
    }
    
    func addCard(_ card: PokemonCard) {
        cards.append(card)
        updateTotalValue()
        saveCards()
    }
    
    func removeCard(_ card: PokemonCard) {
        cards.removeAll { $0.id == card.id }
        updateTotalValue()
        saveCards()
    }
    
    func getCardsBySet(_ set: String) -> [PokemonCard] {
        return cards.filter { $0.set == set }
    }
    
    func getCardsByRarity(_ rarity: CardRarity) -> [PokemonCard] {
        return cards.filter { $0.rarity == rarity }
    }
    
    func getCardsByType(_ type: PokemonType) -> [PokemonCard] {
        return cards.filter { $0.types.contains(type) }
    }
    
    func searchCards(query: String) -> [PokemonCard] {
        if query.isEmpty {
            return cards
        }
        return cards.filter { card in
            card.name.localizedCaseInsensitiveContains(query) ||
            card.set.localizedCaseInsensitiveContains(query) ||
            card.number.localizedCaseInsensitiveContains(query)
        }
    }
    
    var uniqueSets: [String] {
        Array(Set(cards.map { $0.set })).sorted()
    }
    
    var rarityCounts: [CardRarity: Int] {
        var counts: [CardRarity: Int] = [:]
        for rarity in CardRarity.allCases {
            counts[rarity] = getCardsByRarity(rarity).count
        }
        return counts
    }
    
    var typeCounts: [PokemonType: Int] {
        var counts: [PokemonType: Int] = [:]
        for type in PokemonType.allCases {
            counts[type] = getCardsByType(type).count
        }
        return counts
    }
    
    private func updateTotalValue() {
        totalValue = cards.compactMap { $0.marketValue }.reduce(0, +)
    }
    
    private func saveCards() {
        if let encoded = try? JSONEncoder().encode(cards) {
            UserDefaults.standard.set(encoded, forKey: "SavedCards")
        }
    }
    
    private func loadCards() {
        if let data = UserDefaults.standard.data(forKey: "SavedCards"),
           let decoded = try? JSONDecoder().decode([PokemonCard].self, from: data) {
            cards = decoded
            updateTotalValue()
        }
    }
}

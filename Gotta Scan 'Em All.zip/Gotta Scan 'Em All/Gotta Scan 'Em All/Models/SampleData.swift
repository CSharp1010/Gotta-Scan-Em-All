//
//  SampleData.swift
//  Gotta Scan 'Em All
//
//  Created by Jersain Hermosillo on 9/8/25.
//

import Foundation

struct SampleData {
    static let sampleCards: [PokemonCard] = [
        PokemonCard(
            name: "Pikachu",
            set: "Base Set",
            number: "58/102",
            rarity: .common,
            hp: 40,
            types: [.lightning],
            attacks: [
                Attack(name: "Thunder Shock", cost: [.lightning], damage: "10", text: "Flip a coin. If heads, the Defending Pokémon is now Paralyzed.")
            ],
            marketValue: 5.99
        ),
        PokemonCard(
            name: "Charizard",
            set: "Base Set",
            number: "4/102",
            rarity: .rareHolo,
            hp: 120,
            types: [.fire],
            attacks: [
                Attack(name: "Fire Spin", cost: [.fire, .fire, .fire, .fire], damage: "100", text: "Discard 2 Energy cards attached to Charizard in order to use this attack.")
            ],
            weaknesses: [Weakness(type: .water, value: "×2")],
            marketValue: 299.99
        ),
        PokemonCard(
            name: "Blastoise",
            set: "Base Set",
            number: "2/102",
            rarity: .rareHolo,
            hp: 100,
            types: [.water],
            attacks: [
                Attack(name: "Hydro Pump", cost: [.water, .water, .water, .water], damage: "40+", text: "Does 40 damage plus 10 more damage for each Water Energy attached to Blastoise but not used to pay for this attack's Energy cost. You can't add more than 20 damage in this way.")
            ],
            weaknesses: [Weakness(type: .lightning, value: "×2")],
            marketValue: 199.99
        ),
        PokemonCard(
            name: "Venusaur",
            set: "Base Set",
            number: "15/102",
            rarity: .rareHolo,
            hp: 100,
            types: [.grass],
            attacks: [
                Attack(name: "Solarbeam", cost: [.grass, .grass, .grass, .grass], damage: "60", text: "")
            ],
            weaknesses: [Weakness(type: .fire, value: "×2")],
            marketValue: 149.99
        ),
        PokemonCard(
            name: "Mewtwo",
            set: "Base Set",
            number: "10/102",
            rarity: .rareHolo,
            hp: 60,
            types: [.psychic],
            attacks: [
                Attack(name: "Psychic", cost: [.psychic, .psychic, .psychic], damage: "10+", text: "Does 10 damage plus 10 more damage for each Energy card attached to the Defending Pokémon.")
            ],
            weaknesses: [Weakness(type: .psychic, value: "×2")],
            marketValue: 89.99
        ),
        PokemonCard(
            name: "Alakazam",
            set: "Base Set",
            number: "1/102",
            rarity: .rareHolo,
            hp: 80,
            types: [.psychic],
            attacks: [
                Attack(name: "Confuse Ray", cost: [.psychic, .psychic, .psychic], damage: "30", text: "Flip a coin. If heads, the Defending Pokémon is now Confused.")
            ],
            weaknesses: [Weakness(type: .psychic, value: "×2")],
            marketValue: 79.99
        ),
        PokemonCard(
            name: "Machamp",
            set: "Base Set",
            number: "8/102",
            rarity: .rareHolo,
            hp: 100,
            types: [.fighting],
            attacks: [
                Attack(name: "Seismic Toss", cost: [.fighting, .fighting, .fighting, .fighting], damage: "60", text: "")
            ],
            weaknesses: [Weakness(type: .psychic, value: "×2")],
            marketValue: 69.99
        ),
        PokemonCard(
            name: "Gyarados",
            set: "Base Set",
            number: "6/102",
            rarity: .rareHolo,
            hp: 100,
            types: [.water],
            attacks: [
                Attack(name: "Dragon Rage", cost: [.water, .water, .water, .water], damage: "50", text: "")
            ],
            weaknesses: [Weakness(type: .lightning, value: "×2")],
            marketValue: 59.99
        )
    ]
    
    static func populateSampleData(in collection: CardCollection) {
        for card in sampleCards {
            collection.addCard(card)
        }
    }
}

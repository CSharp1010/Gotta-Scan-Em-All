//
//  Gotta_Scan__Em_AllTests.swift
//  Gotta Scan 'Em AllTests
//
//  Created by Jersain Hermosillo on 9/8/25.
//

import Testing

struct Gotta_Scan__Em_AllTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}

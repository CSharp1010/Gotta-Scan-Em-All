//
//  CardRecognitionService.swift
//  Gotta Scan 'Em All
//

import Foundation
import Vision
import UIKit
import SwiftUI

/// Service that runs Vision OCR and then queries the Pokémon TCG API
/// to turn a photo of a card into a `PokemonCard` model.
final class CardRecognitionService: ObservableObject {
    
    @Published var isRecognizing: Bool = false
    @Published var statusMessage: String = "No scan yet."
    
    /// Shared API service
    private let apiService: PokemonTCGAPIService
    
    // MARK: - Init
    
    init(apiService: PokemonTCGAPIService = .shared) {
        self.apiService = apiService
    }
    
    // MARK: - Public API
    
    /// Run OCR + API lookup and return a `PokemonCard` if we can match it.
    /// If the API cannot return a real card and the local DB also fails,
    /// this will return `nil` (NO placeholder card is created).
    func recognizeCard(from image: UIImage, completion: @escaping (PokemonCard?) -> Void) {
        DispatchQueue.main.async {
            self.isRecognizing = true
            self.statusMessage = "Running text recognition…"
        }

        DispatchQueue.global(qos: .userInitiated).async {
            guard let cgImage = image.cgImage else {
                DispatchQueue.main.async {
                    self.isRecognizing = false
                    self.statusMessage = "Invalid image."
                    completion(nil)
                }
                return
            }

            let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
            let request = VNRecognizeTextRequest { req, err in
                if let err = err {
                    print("❌ Vision text recognition failed:", err)
                    DispatchQueue.main.async {
                        self.isRecognizing = false
                        self.statusMessage = "Text recognition failed."
                        completion(nil)
                    }
                    return
                }

                guard let observations = req.results as? [VNRecognizedTextObservation] else {
                    DispatchQueue.main.async {
                        self.isRecognizing = false
                        self.statusMessage = "No text found."
                        completion(nil)
                    }
                    return
                }

                let recognizedLines: [String] = observations.compactMap {
                    $0.topCandidates(1).first?.string
                }

                print("🧾 RAW OCR LINES:")
                for line in recognizedLines { print(" • \(line)") }

                let (primaryName, tokens) = self.extractName(from: recognizedLines)
                let joinedText = recognizedLines.joined(separator: " ")
                let cardNumber = self.extractCardNumber(from: joinedText)

                print("👉 Using name =", primaryName ?? "nil")
                print("🔢 Extracted card number =", cardNumber ?? "nil")

                guard let bestName = primaryName else {
                    DispatchQueue.main.async {
                        self.isRecognizing = false
                        self.statusMessage = "Could not determine card name."
                        completion(nil)
                    }
                    return
                }

                // MAIN SEARCH: API first, but fall back to local DB
                self.searchBestMatchingCards(
                    name: bestName,
                    number: cardNumber,
                    allTokens: tokens
                ) { apiCard in
                    DispatchQueue.main.async {
                        self.isRecognizing = false

                        var finalCard: PokemonCard? = apiCard
                        var usedLocal = false

                        // 🔑 NEW LOGIC:
                        // If API failed OR the API card has no image, try local DB.
                        if apiCard == nil || apiCard?.imageURL == nil {
                            print("💡 Using LocalCardDatabase because API card was nil or had no image.")
                            if let local = LocalCardDatabase.shared.bestLocalMatch(
                                ocrName: bestName,
                                fullNumber: cardNumber,
                                ocrLines: recognizedLines
                            ) {
                                finalCard = local
                                usedLocal = true
                            }
                        }

                        if let card = finalCard {
                            if usedLocal {
                                print("✅ Found local card: \(card.name)")
                                self.statusMessage = "✅ Found \(card.name) (offline)"
                            } else {
                                print("✅ Found API card: \(card.name)")
                                self.statusMessage = "✅ Found \(card.name)"
                            }
                            completion(card)
                        } else {
                            print("❌ No card found in API or local DB.")
                            self.statusMessage = "❌ No matching card found."
                            completion(nil)
                        }
                    }
                }
            }

            request.recognitionLanguages = ["en_US"]
            request.usesLanguageCorrection = true

            do {
                try handler.perform([request])
            } catch {
                print("❌ Vision request failed:", error)
                DispatchQueue.main.async {
                    self.isRecognizing = false
                    self.statusMessage = "Vision request failed."
                    completion(nil)
                }
            }
        }
    }

        
        // MARK: - API search logic
        
        /// Try several (name, number) combinations to get the best match from the API.
        /// If ALL attempts fail (network error, 404, or empty results),
        /// this returns `nil` and does NOT fabricate a PokemonCard.
        private func searchBestMatchingCards(
            name: String,
            number: String?,
            allTokens: [String],
            completion: @escaping (PokemonCard?) -> Void
        ) {
            var attempts: [(String, String?)] = []
            
            // 1) name + full number (e.g. "44/102")
            if let num = number {
                attempts.append((name, num))
                
                // 2) name + first part of "44/102" => "44"
                if let slashIdx = num.firstIndex(of: "/") {
                    let firstPart = String(num[..<slashIdx])
                    if firstPart != num {
                        attempts.append((name, firstPart))
                    }
                }
            }
            
            // 3) name only
            attempts.append((name, nil))
            
            // 4) number only (fallback)
            if let num = number {
                attempts.append(("", num))
            }
            
            func tryNext() {
                guard !attempts.isEmpty else {
                    print("❌ Exhausted all API search attempts – no real card found.")
                    completion(nil)
                    return
                }
                
                let (nextName, nextNumber) = attempts.removeFirst()
                let queryName = nextName.trimmingCharacters(in: .whitespacesAndNewlines)
                
                print("🔍 Attempting API search: name='\(queryName)' number='\(nextNumber ?? "nil")'")
                
                apiService.searchCards(name: queryName, number: nextNumber) { result in
                    switch result {
                    case .success(let apiCards):
                        if let first = apiCards.first {
                            print("✅ API returned \(apiCards.count) cards, using first match: \(first.name) [\(first.id)]")
                            let mapped = first.asPokemonCard()
                            completion(mapped)
                        } else {
                            print("ℹ️ API returned 0 cards for this query, trying next attempt…")
                            tryNext()
                        }
                        
                    case .failure(let error):
                        // Network / timeout / 404 / decode errors – just log and move on
                        print("❌ API error: \(error.localizedDescription) – trying next attempt if any.")
                        tryNext()
                    }
                }
            }
            
            tryNext()
        }
        
        // MARK: - Name parsing (tuned for your sample cards)
        
        /// Returns (primaryName, allNameLikeTokens)
        /// `primaryName` is what we send to the API.
        private func extractName(from lines: [String]) -> (primary: String?, tokens: [String]) {
            
            func tokenize(_ line: String) -> [String] {
                let cleaned = line
                    .replacingOccurrences(of: "/", with: " ")
                    .replacingOccurrences(of: "-", with: " ")
                
                return cleaned
                    .components(separatedBy: .whitespacesAndNewlines)
                    .map { $0.trimmingCharacters(in: .punctuationCharacters) }
                    .filter { !$0.isEmpty }
            }
            
            func isValidNameToken(_ raw: String) -> Bool {
                let token = raw.lowercased()
                
                let exactIgnore: Set<String> = [
                    "pokémon", "pokemon",
                    "basic",
                    "trainer", "supporter", "stadium", "item",
                    "stage", "stage1", "stage2", "stage-1", "stage-2",
                    "ex", "gx", "v", "vmax", "vstar",
                    "ability",
                    "hp", "lv", "lv.", "lvl", "lvl.",
                    "no.", "no",
                    "ht", "ht:", "wt", "wt:", "lbs", "lb", "lb.",
                    "ibs", "height", "weight"
                ]
                
                if exactIgnore.contains(token) { return false }
                if token.hasPrefix("stage") { return false }
                if token.allSatisfy({ $0.isNumber }) { return false }
                if token.lowercased().hasPrefix("lv") && token.contains(".") { return false }
                guard token.first?.isLetter == true else { return false }
                return true
            }
            
            var allTokens: [String] = []
            for line in lines {
                allTokens.append(contentsOf: tokenize(line).map { $0.lowercased() })
            }
            
            let topLines = Array(lines.prefix(6))
            let bottomLines = Array(lines.suffix(6))
            let focusedLines = topLines + bottomLines
            
            // 1) HP-line heuristic: lines that contain "HP"
            for (idx, line) in focusedLines.enumerated() {
                let parts = tokenize(line)
                let lowerParts = parts.map { $0.lowercased() }
                
                guard let hpIndex = lowerParts.firstIndex(where: { $0.contains("hp") }) else { continue }
                
                let beforeHP = parts[..<hpIndex]
                
                // Strip off leading "Basic", "Stage1", etc.
                let filteredLeading = beforeHP.drop(while: { token in
                    let t = token.lowercased()
                    return t == "basic" || t.hasPrefix("stage")
                })
                
                var nameTokens = filteredLeading.filter(isValidNameToken)
                
                // If HP line itself has no tokens (e.g. "40 HP"), try previous line as name.
                if nameTokens.isEmpty, idx > 0 {
                    let prevLine = focusedLines[idx - 1]
                    let prevParts = tokenize(prevLine)
                    let prevTrimmed = prevParts.drop(while: { token in
                        let t = token.lowercased()
                        return t == "basic" || t.hasPrefix("stage")
                    })
                    let prevValid = prevTrimmed.filter(isValidNameToken)
                    if !prevValid.isEmpty {
                        nameTokens = prevValid
                    }
                }
                
                if !nameTokens.isEmpty {
                    let candidate = nameTokens.joined(separator: " ")
                    let filteredTokens = allTokens.filter(isValidNameToken)
                    return (candidate, filteredTokens)
                }
            }
            
            // 2) Fallback: look at top region and pick the most name-like line
            var bestTokens: [String] = []
            var bestScore = Int.min
            
            for (index, line) in topLines.enumerated() {
                let parts = tokenize(line)
                let lowerLine = line.lowercased()
                let lowerTokens = parts.map { $0.lowercased() }
                
                // skip "Evolves from ..." etc.
                if lowerLine.contains("evolves from") { continue }
                
                if lowerLine == "trainer" || lowerLine == "supporter" { continue }
                
                let measurementTokens: Set<String> = [
                    "no", "no.", "ht", "ht:", "wt", "wt:",
                    "lbs", "lb", "lb.", "height", "weight", "ibs"
                ]
                if lowerTokens.contains(where: { measurementTokens.contains($0) }) { continue }
                
                let effectWords: Set<String> = [
                    "unless", "damage", "attack", "energy", "cards",
                    "deck", "shuffle", "prevented", "flip", "coin", "discard"
                ]
                if lowerTokens.contains(where: { effectWords.contains($0) }) {
                    continue
                }
                
                let trimmedParts = parts.drop(while: { token in
                    let t = token.lowercased()
                    return t == "basic" || t.hasPrefix("stage")
                })
                
                let valid = trimmedParts.filter(isValidNameToken)
                guard !valid.isEmpty else { continue }
                
                // Score/name-likeness
                let count = valid.count
                var score = 0
                score -= count * 10       // fewer tokens is better
                score -= index * 2        // nearer the top is better
                
                if count == 1 { score += 30 }  // "Bulbasaur"
                if count == 2 { score += 10 }  // "Latias ex"
                
                if lowerTokens.contains(where: { $0.hasPrefix("lv") }) {
                    score += 25
                }
                if index == 0 {
                    score += 15
                }
                
                if score > bestScore {
                    bestScore = score
                    bestTokens = valid
                }
            }
            
            let primaryName = bestTokens.isEmpty ? nil : bestTokens.joined(separator: " ")
            let fallbackTokens = allTokens.filter(isValidNameToken)
            return (primaryName, fallbackTokens)
        }
        
        // MARK: - Card number parsing  (captures things like "44/102")
        
        private func extractCardNumber(from text: String) -> String? {
            let nsText = text as NSString
            let pattern = #"(\d{1,3}/\d{1,3})"#
            guard let regex = try? NSRegularExpression(pattern: pattern, options: []) else {
                return nil
            }
            
            let range = NSRange(location: 0, length: nsText.length)
            if let match = regex.firstMatch(in: text, options: [], range: range),
               match.numberOfRanges >= 2 {
                return nsText.substring(with: match.range(at: 1))  // e.g. "44/102"
            }
            return nil
        }
    }
    
    


//
//  PokemonCardSearchg.swift
//  Gotta Scan 'Em All
//
//  Thin wrapper around PokemonTCGAPIService for simple searches.
//

import Foundation

/// Simple service that wraps PokemonTCGAPIService for searching a single card.
final class PokemonCardSearchService {

    private let api: PokemonTCGAPIService

    init(api: PokemonTCGAPIService = .shared) {
        self.api = api
    }

    /// Search for the first matching API card and return it.
    func searchCard(
        name: String,
        number: String?,
        completion: @escaping (PokemonTCGAPIService.PokemonTCGCard?) -> Void
    ) {
        api.searchCards(name: name, number: number) { result in
            switch result {
            case .success(let cards):
                completion(cards.first)
            case .failure:
                completion(nil)
            }
        }
    }
}


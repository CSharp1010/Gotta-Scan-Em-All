//
//  LocalCardDatabase.swift
//  Gotta Scan 'Em All
//
//  Small, hand-curated database for Casey’s physical cards.
//  Used to (a) avoid API timeouts, and (b) disambiguate versions.
//

import Foundation

final class LocalCardDatabase {

    static let shared = LocalCardDatabase()

    // Represents one known physical card you own.
    struct Entry {
        /// Canonical name ("Bulbasaur", "Latias ex", "Lt. Surge's Eevee")
        let name: String

        /// Printed number on the card, including denominator ("44/102", "239/191", "150/165", "1/18", …)
        let printedNumber: String?

        /// Simple number (numerator only, like "44", "239", "150", "1") for older logic / fuzzy match.
        let simpleNumber: String?

        /// Human-readable set name ("Base Set", "McDonald’s 2019", "Scarlet & Violet", …)
        let setName: String

        /// Rarity in your app’s enum
        let rarity: CardRarity

        /// HP on the card (if present)
        let hp: Int?

        /// Types in your app’s PokemonType enum (use .fire, .grass, .water, .lightning, .psychic, etc.)
        let types: [PokemonType]

        /// Artist line (optional)
        let artist: String?

        /// Your best guess at value (optional, can be nil)
        let estimatedValue: Double?

        /// Name of an image in Assets.xcassets for this exact printing.
        /// e.g. "bulbasaur_44_102"
        let assetName: String?

        /// Extra hints that can appear in OCR text:
        /// years ("1999", "2019"), publishers ("wizards"), rule text ("pokémon ex rule"), etc.
        let hintTokens: [String]
    }

    // MARK: - Known cards
    // NOTE: tweak set names, hp, rarity, marketValue, and assetName to match your project.

    private let entries: [Entry] = [

        // MARK: Bulbasaur – Base Set 44/102
        Entry(
            name: "Bulbasaur",
            printedNumber: "44/102",
            simpleNumber: "44",
            setName: "Base Set",
            rarity: .common,
            hp: 40,
            types: [.grass],
            artist: "Mitsuhiro Arita",
            estimatedValue: 3.0,
            assetName: "bulbasaur_44_102", // <-- make an asset with this name
            hintTokens: ["1999", "wizards", "length: 2' 4", "wizards.", "creatures, gamefreak"]
        ),

        // MARK: Bulbasaur – McDonald’s style 1/18
        Entry(
            name: "Bulbasaur",
            printedNumber: "1/18",
            simpleNumber: "1",
            setName: "Promo",
            rarity: .common,
            hp: 60,
            types: [.grass],
            artist: "MPC Film",
            estimatedValue: 1.0,
            assetName: "bulbasaur_1_18",
            hintTokens: ["2019", "mcdonald", "mpc film", "1/18"]
        ),

        // MARK: Charmander – Base Set 46/102
        Entry(
            name: "Charmander",
            printedNumber: "46/102",
            simpleNumber: "46",
            setName: "Base Set",
            rarity: .common,
            hp: 50,
            types: [.fire],
            artist: "Mitsuhiro Arita",
            estimatedValue: 3.0,
            assetName: "charmander_46_102",
            hintTokens: ["scratch", "ember", "1999", "wizards"]
        ),

        // MARK: Pikachu – classic style 112/111 (your earlier OCR)
        Entry(
            name: "Pikachu",
            printedNumber: "112/111",
            simpleNumber: "112",
            setName: "Risinng Rivals",
            rarity: .secretRare,
            hp: 40,
            types: [.lightning],
            artist: "Mitsuhiro Arita",
            estimatedValue: 10.0,
            assetName: "pikachu112",
            hintTokens: ["thunder jolt", "gnaw", "mouse pokémon", "©2009 pokémon"]
        ),

        // MARK: Pikachu ex (modern)
        Entry(
            name: "Pikachu ex",
            printedNumber: "219/191",          // we can still match by name + hints
            simpleNumber: "219",
            setName: "Scarlet & Violet",
            rarity: .ultraRare,
            hp: 190,
            types: [.lightning],
            artist: nil,
            estimatedValue: 5.0,
            assetName: "pikachu_ex",
            hintTokens: ["pokémon ex rule", "when your pokémon ex is knocked out"]
        ),

        // MARK: Mewtwo – 150/165
        Entry(
            name: "Mewtwo",
            printedNumber: "150/165",
            simpleNumber: "150",
            setName: "Scarlet & Violet 151",
            rarity: .rare,
            hp: 130,
            types: [.psychic],
            artist: "AKIRA EGAWA",
            estimatedValue: 5.0,
            assetName: "mewtwo_150_165",
            hintTokens: ["genetic pokémon", "recombining mew's genes", "2023 pokémon", "151/"]
        ),

        // MARK: Latias ex – 239/191
        Entry(
            name: "Latias ex",
            printedNumber: "239/191",
            simpleNumber: "239",
            setName: "Scarlet & Violet",
            rarity: .secretRare,
            hp: 210,
            types: [.psychic],
            artist: "OKACHEKE",
            estimatedValue: 15.0,
            assetName: "latias_ex_239_191",
            hintTokens: ["skyliner", "eon blade", "pokémon ex rule", "239/191", "2024 pokémon"]
        ),


        // MARK: Maxie's Trainer (Supporter)
        Entry(
            name: "Maxie's Hidden Ball Trick",
            printedNumber: "158/160",
            simpleNumber: "150",
            setName: "Trainer",
            rarity: .rare,
            hp: nil,
            types: [],
            artist: nil,
            estimatedValue: 2.0,
            assetName: "maxies_trainer",
            hintTokens: ["maxie", "supporter", "team magma"]
        ),

        // MARK: Voltorb (basic, lightning type)
        Entry(
            name: "Voltorb",
            printedNumber: "100/165",
            simpleNumber: "100",
            setName: "Scarlet & Violet",
            rarity: .common,
            hp: 40,
            types: [.lightning],
            artist: "nogimiso",
            estimatedValue: 1.0,
            assetName: "voltorb100",
            hintTokens: ["ball pokémon", "voltorb"]
        ),

        // MARK: Quaquaval (newer card you showed)
        Entry(
            name: "Quaquaval",
            printedNumber: "054/198",
            simpleNumber: "054",
            setName: "Scarlet & Violet",
            rarity: .rare,
            hp: 170,
            types: [.water],
            artist: nil,
            estimatedValue: 3.0,
            assetName: "quaquaval_default",
            hintTokens: ["quaquaval", "aqua", "water pokémon"]
        )
    ]

    // MARK: - Public API

    /// Try to find the *best* local match for this OCR result.
    ///
    /// - Parameters:
    ///   - ocrName: what the OCR believes the card name is (e.g. "Bulbasaur", "Latias ex")
    ///   - fullNumber: the full printed number, like "44/102" or "239/191" (can be nil)
    ///   - ocrLines: all OCR lines, for hint matching ("1999 Wizards", "Pokémon ex rule", etc.)
    ///
    /// - Returns: A fully-populated `PokemonCard` if we are confident, otherwise nil.
    func bestLocalMatch(ocrName: String, fullNumber: String?, ocrLines: [String]) -> PokemonCard? {
        let normalizedName = ocrName
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()

        let joinedText = ocrLines.joined(separator: " ").lowercased()
        let numerator: String? = fullNumber?.split(separator: "/").first.map { String($0) }

        var scored: [(entry: Entry, score: Int)] = []

        for entry in entries {
            var score = 0

            // 1. Name match – mandatory for now
            let entryName = entry.name.lowercased()

            if entryName == normalizedName {
                // Exact match – strong boost
                score += 80
            } else if normalizedName.contains(entryName) || entryName.contains(normalizedName) {
                // e.g. OCR "Latias eX" vs "Latias ex"
                score += 40
            } else {
                continue // if we can't match name at all, skip
            }

            // 2. Full printed number match ("44/102", "239/191", etc.)
            if let fn = fullNumber, let printed = entry.printedNumber {
                if fn == printed {
                    score += 80
                } else if fn.lowercased() == printed.lowercased() {
                    score += 60
                }
            }

            // 3. Simple number match (just numerator)
            if let n = numerator,
               let simple = entry.simpleNumber,
               n == simple {
                score += 30
            }

            // 4. Hint tokens (years, publishers, rule text, etc.)
            for hint in entry.hintTokens {
                if joinedText.contains(hint.lowercased()) {
                    score += 10
                }
            }

            if score > 0 {
                scored.append((entry, score))
            }
        }

        guard let best = scored.max(by: { $0.score < $1.score }) else {
            return nil
        }

        let e = best.entry

        // Build a PokemonCard using your app’s model
        return PokemonCard(
            name: e.name,
            set: e.setName,
            number: e.printedNumber ?? e.simpleNumber ?? "",
            rarity: e.rarity,
            imageURL: nil,                // we use local asset instead
            localImagePath: e.assetName,  // <- CardImageView should show this if present
            hp: e.hp,
            types: e.types,
            attacks: [],
            weaknesses: [],
            resistances: [],
            retreatCost: nil,
            artist: e.artist,
            marketValue: e.estimatedValue
        )
    }
}



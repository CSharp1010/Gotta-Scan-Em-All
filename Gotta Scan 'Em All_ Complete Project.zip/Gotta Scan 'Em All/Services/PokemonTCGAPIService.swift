//
//  PokemonTCGAPIService.swift
//  Gotta Scan 'Em All
//

import Foundation

/// Handles calls to the Pokemon TCG API (v2)
final class PokemonTCGAPIService {

    // MARK: - Configuration

    /// Your API key from https://dev.pokemontcg.io
    private let apiKey = "f256cb04-e240-412e-9016-41539a066a70"

    /// Optional shared instance if you want singleton style
    static let shared = PokemonTCGAPIService()

    /// Use a custom session so we can control timeouts & connectivity behavior
    private let session: URLSession

    /// Public initializer so other types can do `PokemonTCGAPIService()`
    init() {
        let config = URLSessionConfiguration.default
        // How long we’ll wait for each request before giving up
        config.timeoutIntervalForRequest = 15       // seconds
        config.timeoutIntervalForResource = 30      // seconds
        // If the network is briefly unavailable, wait instead of immediately failing
        config.waitsForConnectivity = true

        self.session = URLSession(configuration: config)
    }

    // MARK: - API Models

    struct PokemonTCGCard: Codable, Identifiable, Hashable {
        let id: String
        let name: String
        let number: String?
        let rarity: String?
        let artist: String?
        let hp: String?
        let types: [String]?
        let convertedRetreatCost: Int?
        let images: Images?
        let tcgplayer: TCGPlayerPrices?
        let set: SetInfo?

        struct Images: Codable, Hashable {
            let small: String?
            let large: String?
        }

        struct SetInfo: Codable, Hashable {
            let id: String?
            let name: String?
        }

        struct TCGPlayerPrices: Codable, Hashable {
            let prices: Prices?
        }

        struct Prices: Codable, Hashable {
            let holofoil: PriceEntry?
            let reverseHolofoil: PriceEntry?
            let normal: PriceEntry?
            let firstEditionHolofoil: PriceEntry?
            let firstEditionNormal: PriceEntry?
        }

        struct PriceEntry: Codable, Hashable {
            let market: Double?
        }
    }

    enum APIError: Error {
        case invalidURL
        case invalidResponse(status: Int)
        case noData
        case networkTimeout
        case other(Error)

        var localizedDescription: String {
            switch self {
            case .invalidURL:
                return "Invalid API URL"
            case .invalidResponse(let status):
                return "Invalid response from server (HTTP \(status))"
            case .noData:
                return "No data received from server"
            case .networkTimeout:
                return "The request to the Pokémon TCG API timed out"
            case .other(let error):
                return error.localizedDescription
            }
        }

        var code: Int {
            switch self {
            case .invalidURL: return 0
            case .invalidResponse: return 1
            case .noData: return 2
            case .networkTimeout: return 3
            case .other: return 4
            }
        }
    }

    private let baseURL = URL(string: "https://api.pokemontcg.io/v2/cards")!

    // MARK: - Public search API

    /// Main search entry point – used by CardRecognitionService.
    func searchCards(
        name: String,
        number: String?,
        completion: @escaping (Result<[PokemonTCGCard], APIError>) -> Void
    ) {
        var components = URLComponents(url: baseURL, resolvingAgainstBaseURL: false)!

        var qParts: [String] = []

        let trimmedName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        if !trimmedName.isEmpty {
            // quoted to force phrase match on card name
            qParts.append("name:\"\(trimmedName)\"")
        }

        if let num = number?.trimmingCharacters(in: .whitespacesAndNewlines),
           !num.isEmpty {
            // Allow both simple and full "44/102" style numbers
            qParts.append("number:\"\(num)\"")
        }

        // If we have no query at all, don't hit the network
        guard !qParts.isEmpty else {
            completion(.success([]))
            return
        }

        components.queryItems = [
            URLQueryItem(name: "q", value: qParts.joined(separator: " ")),
            URLQueryItem(name: "pageSize", value: "250") // 20 is fine; you can remove this if you want
        ]

        guard let url = components.url else {
            completion(.failure(.invalidURL))
            return
        }

        var request = URLRequest(url: url)
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue(apiKey, forHTTPHeaderField: "X-Api-Key")

        print("🌐 API Request: \(url.absoluteString)")

        session.dataTask(with: request) { data, response, error in
            // Handle low-level networking error
            if let error = error as? URLError {
                if error.code == .timedOut {
                    print("⏱️ Network timeout calling PokemonTCG API: \(error)")
                    completion(.failure(.networkTimeout))
                } else {
                    print("❌ URLError calling PokemonTCG API: \(error)")
                    completion(.failure(.other(error)))
                }
                return
            } else if let error = error {
                print("❌ Network error: \(error)")
                completion(.failure(.other(error)))
                return
            }

            guard let http = response as? HTTPURLResponse else {
                completion(.failure(.invalidResponse(status: -1)))
                return
            }

            print("📡 API Response: HTTP \(http.statusCode)")

            guard http.statusCode == 200 else {
                completion(.failure(.invalidResponse(status: http.statusCode)))
                return
            }

            guard let data = data else {
                completion(.failure(.noData))
                return
            }

            do {
                struct Root: Codable { let data: [PokemonTCGCard] }
                let decoded = try JSONDecoder().decode(Root.self, from: data)
                print("✅ Decoded \(decoded.data.count) cards")
                completion(.success(decoded.data))
            } catch {
                print("❌ Decoding error: \(error)")
                completion(.failure(.other(error)))
            }
        }.resume()
    }
}

// MARK: - Mapping: API card → app PokemonCard

extension PokemonTCGAPIService.PokemonTCGCard {
    func asPokemonCard() -> PokemonCard {
        // Rarity
        let rarityEnum = CardRarity(rawValue: rarity ?? "") ?? .common

        // HP (API is String)
        let hpValue: Int? = {
            guard let hp = hp, !hp.isEmpty else { return nil }
            return Int(hp)
        }()

        // Types
        let typeEnums: [PokemonType] = (types ?? []).compactMap { PokemonType(rawValue: $0) }

        // Retreat cost
        let retreat = convertedRetreatCost

        // Market value from tcgplayer
        let marketValue: Double? = {
            guard let prices = tcgplayer?.prices else { return nil }
            return prices.holofoil?.market ??
                   prices.reverseHolofoil?.market ??
                   prices.normal?.market ??
                   prices.firstEditionHolofoil?.market ??
                   prices.firstEditionNormal?.market
        }()

        // Prefer large image, fall back to small
        let imageURL = images?.large ?? images?.small

        return PokemonCard(
            name: name,
            set: set?.name ?? "Unknown Set",
            number: number ?? "",
            rarity: rarityEnum,
            imageURL: imageURL,
            localImagePath: nil,
            hp: hpValue,
            types: typeEnums,
            attacks: [],
            weaknesses: [],
            resistances: [],
            retreatCost: retreat,
            artist: artist,
            marketValue: marketValue
        )
    }
}


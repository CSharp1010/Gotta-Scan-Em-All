//
//  ScannerView.swift
//  Gotta Scan 'Em All
//

import SwiftUI
import UIKit

struct ScannerView: View {
    @EnvironmentObject var cardCollection: CardCollection
    @StateObject private var recognizer = CardRecognitionService()

    @State private var showingImagePicker = false
    @State private var selectedImage: UIImage?
    @State private var isScanning = false

    // Status line under the buttons
    @State private var statusMessage: String = "No scan yet."
    @State private var statusColor: Color = .secondary

    var body: some View {
        NavigationView {
            VStack(alignment: .leading, spacing: 32) {
                // Title
                Text("Scanner")
                    .font(.largeTitle)
                    .bold()

                // Big icon + title + subtitle
                VStack(spacing: 12) {
                    ZStack {
                        Circle()
                            .fill(Color.blue.opacity(0.1))
                            .frame(width: 120, height: 120)

                        Image(systemName: "viewfinder")
                            .font(.system(size: 44, weight: .medium))
                            .foregroundColor(.blue)
                    }

                    Text("Scan Pokémon Cards")
                        .font(.title3)
                        .fontWeight(.semibold)

                    Text("Select a card from your gallery to scan and add it to your collection.")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                }
                .frame(maxWidth: .infinity)

                // Buttons: Scan Card / Add Manually
                VStack(spacing: 12) {
                    Button(action: {
                        showingImagePicker = true
                    }) {
                        HStack {
                            Image(systemName: "photo.on.rectangle")
                            Text("Scan Card")
                                .fontWeight(.semibold)
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(14)
                    }

                    NavigationLink {
                        ManualEntryView()
                            .environmentObject(cardCollection)
                    } label: {
                        HStack {
                            Image(systemName: "square.and.pencil")
                            Text("Add Manually")
                                .fontWeight(.semibold)
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue.opacity(0.08))
                        .foregroundColor(Color.blue)
                        .cornerRadius(14)
                    }
                }

                // Scanning indicator
                if isScanning {
                    HStack(spacing: 8) {
                        ProgressView()
                        Text("Scanning card…")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }

                // Status line (success / error / idle)
                Text(statusMessage)
                    .font(.caption)
                    .foregroundColor(statusColor)
                    .frame(maxWidth: .infinity, alignment: .leading)

                Spacer()

                // Collection summary card at bottom
                collectionSummaryCard
            }
            .padding()
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarHidden(true)
        }
        .sheet(isPresented: $showingImagePicker) {
            ImagePicker(selectedImage: $selectedImage)
        }
        .onChange(of: selectedImage) { image in
            guard let image else { return }
            startRecognition(with: image)
        }
    }

    // MARK: - Summary card

    private var collectionSummaryCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Your Collection")
                .font(.headline)

            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Cards")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    Text("\(cardCollection.totalCards)")
                        .font(.title3)
                        .fontWeight(.semibold)
                }

                Spacer()

                VStack(alignment: .trailing, spacing: 4) {
                    Text("Value")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    Text(cardCollection.totalMarketValue,
                         format: .currency(code: "USD"))
                        .font(.title3)
                        .fontWeight(.semibold)
                }
            }
        }
        .padding()
        .frame(maxWidth: .infinity)
        .background(
            LinearGradient(
                colors: [Color.blue.opacity(0.08), Color.blue.opacity(0.02)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .cornerRadius(20)
    }

    // MARK: - Recognition

    private func startRecognition(with image: UIImage) {
        isScanning = true
        statusMessage = "Scanning card…"
        statusColor = .secondary

        recognizer.recognizeCard(from: image) { card in
            DispatchQueue.main.async {
                isScanning = false

                guard let card else {
                    // ❌ Error status
                    statusMessage = "Could not recognize a Pokémon card. Try a clearer photo."
                    statusColor = .red
                    return
                }

                // ✅ Success: add to collection & show success
                cardCollection.addCard(card)
                statusMessage = "Added \(card.name) #\(card.number) to your collection."
                statusColor = .green
            }
        }
    }
}

// MARK: - Preview

struct ScannerView_Previews: PreviewProvider {
    static var previews: some View {
        ScannerView()
            .environmentObject(CardCollection())
    }
}


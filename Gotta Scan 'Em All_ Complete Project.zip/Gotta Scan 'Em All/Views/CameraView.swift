//
//  CameraView.swift
//  Gotta Scan 'Em All
//
//  Created by Casey S. 
//

import SwiftUI
import AVFoundation
import UIKit

struct CameraView: View {
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var cardCollection: CardCollection
    @EnvironmentObject var imageProcessor: ImageProcessor
    @StateObject private var cameraManager = CameraManager()
    @State private var showingCardDetails = false
    @State private var showingImagePicker = false
    @State private var selectedImage: UIImage?
    @State private var recognizedCard: PokemonCard?
    @State private var showingCameraError = false
    
    var body: some View {
        NavigationView {
            ZStack {
                if cameraManager.isAuthorized && cameraManager.error == nil {
                    // Real Camera Preview
                    LiveCameraPreview(session: cameraManager.session)
                        .ignoresSafeArea()
                    
                    // Camera Overlay
                    VStack {
                        // Top Controls
                        HStack {
                            // Cancel Button
                            Button(action: {
                                cameraManager.stopSession()
                                imageProcessor.cancelProcessing()
                                presentationMode.wrappedValue.dismiss()
                            }) {
                                Image(systemName: "xmark")
                                    .font(.title2)
                                    .foregroundColor(.white)
                                    .frame(width: 44, height: 44)
                                    .background(.ultraThinMaterial)
                                    .clipShape(Circle())
                            }
                            
                            Spacer()
                            
                            // Switch Camera Button
                            Button(action: {
                                cameraManager.stopSession()
                                DispatchQueue.main.async {
                                    cameraManager.switchCamera()
                                    cameraManager.startSession()
                                }
                            }) {
                                Image(systemName: "camera.rotate")
                                    .font(.title2)
                                    .foregroundColor(.white)
                                    .frame(width: 44, height: 44)
                                    .background(.ultraThinMaterial)
                                    .clipShape(Circle())
                            }
                        }
                        .padding()
                        
                        Spacer()
                        
                        // Card Scanning Guide
                        VStack(spacing: 12) {
                            Text("Position the card within the frame")
                                .font(.headline)
                                .foregroundColor(.white)
                                .multilineTextAlignment(.center)
                            
                            // Card Frame Guide
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(Color.white, lineWidth: 2)
                                .frame(width: 280, height: 200)
                                .overlay(
                                    VStack {
                                        HStack {
                                            Circle()
                                                .fill(Color.white)
                                                .frame(width: 8, height: 8)
                                            Spacer()
                                            Circle()
                                                .fill(Color.white)
                                                .frame(width: 8, height: 8)
                                        }
                                        Spacer()
                                        HStack {
                                            Circle()
                                                .fill(Color.white)
                                                .frame(width: 8, height: 8)
                                            Spacer()
                                            Circle()
                                                .fill(Color.white)
                                                .frame(width: 8, height: 8)
                                        }
                                    }
                                    .padding(16)
                                )
                        }
                        .padding(.bottom, 100)
                        
                        // Bottom Controls
                        HStack(spacing: 40) {
                            // Photo Library Button
                            Button(action: {
                                showingImagePicker = true
                            }) {
                                Image(systemName: "photo.on.rectangle")
                                    .font(.title2)
                                    .foregroundColor(.white)
                                    .frame(width: 60, height: 60)
                                    .background(.ultraThinMaterial)
                                    .clipShape(Circle())
                            }
                            
                            // Capture Button
                            Button(action: {
                                cameraManager.capturePhoto()
                            }) {
                                ZStack {
                                    Circle()
                                        .fill(Color.white)
                                        .frame(width: 80, height: 80)
                                    
                                    Circle()
                                        .stroke(Color.black, lineWidth: 3)
                                        .frame(width: 70, height: 70)
                                }
                            }
                            
                            // Placeholder for symmetry
                            Color.clear
                                .frame(width: 60, height: 60)
                        }
                        .padding(.bottom, 50)
                    }
                } else if cameraManager.error == .configurationFailed {
                    // Simulator or Camera Configuration Failed
                    VStack(spacing: 20) {
                        Image(systemName: "camera.fill")
                            .font(.system(size: 60))
                            .foregroundColor(.blue)
                        
                        Text("Camera Not Available")
                            .font(.title2)
                            .fontWeight(.semibold)
                        
                        Text("Camera functionality is not available in the simulator. Use the photo library button below to test with sample images.")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal)
                        
                        Button("Use Photo Library") {
                            showingImagePicker = true
                        }
                        .buttonStyle(.borderedProminent)
                        
                        Button("Cancel") {
                            cameraManager.stopSession()
                            imageProcessor.cancelProcessing()
                            presentationMode.wrappedValue.dismiss()
                        }
                        .buttonStyle(.bordered)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    // Camera Not Authorized
                    VStack(spacing: 20) {
                        Image(systemName: "camera.fill")
                            .font(.system(size: 60))
                            .foregroundColor(.gray)
                        
                        Text("Camera Access Required")
                            .font(.title2)
                            .fontWeight(.semibold)
                        
                        Text("Please allow camera access in Settings to scan Pokémon cards")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal)
                        
                        Button("Open Settings") {
                            if let settingsURL = URL(string: UIApplication.openSettingsURLString) {
                                UIApplication.shared.open(settingsURL)
                            }
                        }
                        .buttonStyle(.borderedProminent)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color(.systemBackground))
                }
            }
            .navigationBarHidden(true)
            .onAppear {
#if targetEnvironment(simulator)
                // On Simulator, do not start the camera; show the library path instead and wait for user action
                cameraManager.error = .configurationFailed
#else
                DispatchQueue.main.async {
                    cameraManager.startSession()
                }
#endif
            }
            .onDisappear {
                cameraManager.stopSession()
            }
            .onChange(of: cameraManager.capturedImage) { image in
                if let image = image {
                    processCapturedImage(image)
                }
            }
            .onChange(of: selectedImage) { image in
                if let image = image {
                    processCapturedImage(image)
                }
            }
            .sheet(isPresented: $showingImagePicker, onDismiss: {
                // If recognition completed while the picker was presented, show confirmation now
                if recognizedCard != nil {
                    showingCardDetails = true
                }
            }) {
                ImagePicker(selectedImage: $selectedImage)
            }
            .sheet(isPresented: $showingCardDetails) {
                if let card = recognizedCard {
                    CardConfirmationView(
                        card: card,
                        capturedImage: cameraManager.capturedImage ?? selectedImage,
                        detectedText: [] // Camera view doesn't have detected text yet
                    )
                    .environmentObject(cardCollection)
                }
            }
        }
    }
    
    private func processCapturedImage(_ image: UIImage) {
        // Use card recognition service to identify the card
        let recognitionService = CardRecognitionService()
        
        recognitionService.recognizeCard(from: image) { card in
            if let suggestedCard = card {
                // Use the recognized card
                recognizedCard = suggestedCard
            } else {
                // Fallback to a generic card
                let fallbackCard = PokemonCard(
                    name: "Scanned Card",
                    set: "Unknown Set",
                    number: "?/?",
                    rarity: .common,
                    hp: nil,
                    types: [],
                    marketValue: nil
                )
                recognizedCard = fallbackCard
            }
            
            if !showingImagePicker {
                showingCardDetails = true
            }
        }
    }
}

struct LiveCameraPreview: UIViewRepresentable {
    let session: AVCaptureSession

    // Use a uniquely named UIView subclass to avoid ambiguity
    func makeUIView(context: Context) -> AVCameraPreviewView {
        let view = AVCameraPreviewView()
        view.videoPreviewLayer.session = session
        view.videoPreviewLayer.videoGravity = .resizeAspectFill
        return view
    }

    func updateUIView(_ uiView: AVCameraPreviewView, context: Context) {
        if uiView.videoPreviewLayer.session !== session {
            uiView.videoPreviewLayer.session = session
        }
        // Keep gravity consistent
        if uiView.videoPreviewLayer.videoGravity != .resizeAspectFill {
            uiView.videoPreviewLayer.videoGravity = .resizeAspectFill
        }
    }
}

final class AVCameraPreviewView: UIView {
    override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }
    var videoPreviewLayer: AVCaptureVideoPreviewLayer { layer as! AVCaptureVideoPreviewLayer }
}

struct CardConfirmationView: View {
    let card: PokemonCard
    let capturedImage: UIImage?
    let detectedText: [String]
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var cardCollection: CardCollection
    @StateObject private var imageProcessor = ImageProcessor()
    @State private var showingSuccess = false
    @State private var showingManualEdit = false
    @State private var editedCard: PokemonCard
    @State private var showingDetectedText = false
    
    init(card: PokemonCard, capturedImage: UIImage?, detectedText: [String] = []) {
        self.card = card
        self.capturedImage = capturedImage
        self.detectedText = detectedText
        self._editedCard = State(initialValue: card)
    }
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // Card Image
                    VStack(spacing: 12) {
                        if let image = capturedImage {
                            Image(uiImage: image)
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(maxHeight: 300)
                                .cornerRadius(12)
                            
                            if imageProcessor.isProcessing {
                                HStack {
                                    ProgressView()
                                        .scaleEffect(0.8)
                                    Text("Processing image...")
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }
                            }
                            
                            if let processedImage = imageProcessor.processedImage, processedImage != image {
                                Text("Enhanced Image")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                                
                                Image(uiImage: processedImage)
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(maxHeight: 200)
                                    .cornerRadius(12)
                            }
                        } else {
                            CardImageView(card: editedCard)
                                .aspectRatio(0.7, contentMode: .fit)
                                .cornerRadius(12)
                                .frame(height: 300)
                        }
                    }
                    
                    // Card Details
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Text("Card Details")
                                .font(.headline)
                            
                            Spacer()
                            
                            Button("Edit") {
                                showingManualEdit = true
                            }
                            .font(.caption)
                            .foregroundColor(.blue)
                        }
                        
                        DetailRow(label: "Name", value: editedCard.name)
                        DetailRow(label: "Set", value: editedCard.set)
                        DetailRow(label: "Number", value: editedCard.number)
                        DetailRow(label: "Rarity", value: editedCard.rarity.rawValue)
                        
                        if let hp = editedCard.hp {
                            DetailRow(label: "HP", value: "\(hp)")
                        }
                        
                        if !editedCard.types.isEmpty {
                            DetailRow(label: "Type", value: editedCard.types.map { $0.rawValue }.joined(separator: ", "))
                        }
                        
                        if let value = editedCard.marketValue {
                            DetailRow(label: "Estimated Value", value: String(format: "$%.2f", value))
                        }
                    }
                    .padding()
                    .background(Color(.systemBackground))
                    .cornerRadius(12)
                    .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: 1)
                    
                    // Detected Text Section (if available)
                    if !detectedText.isEmpty {
                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                Text("Scanned Text")
                                    .font(.headline)
                                Spacer()
                                Button(action: {
                                    showingDetectedText.toggle()
                                }) {
                                    Image(systemName: showingDetectedText ? "chevron.up" : "chevron.down")
                                        .font(.caption)
                                        .foregroundColor(.blue)
                                }
                            }
                            
                            if showingDetectedText {
                                ScrollView {
                                    VStack(alignment: .leading, spacing: 4) {
                                        ForEach(detectedText, id: \.self) { text in
                                            Text(text)
                                                .font(.caption)
                                                .foregroundColor(.secondary)
                                                .padding(.vertical, 2)
                                        }
                                    }
                                }
                                .frame(maxHeight: 100)
                                
                                Text("Use this text to help fill in card details")
                                    .font(.caption2)
                                    .foregroundColor(.secondary)
                                    .italic()
                            }
                        }
                        .padding()
                        .background(Color.blue.opacity(0.05))
                        .cornerRadius(8)
                    }
                    
                    // Recognition Status
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Recognition Status")
                            .font(.headline)
                        
                        if editedCard.name == "Scanned Card" || editedCard.set == "Unknown Set" {
                            HStack {
                                Image(systemName: "exclamationmark.triangle.fill")
                                    .foregroundColor(.orange)
                                Text("Card details were not automatically recognized")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                            
                            Text("Please edit the details above or add manually")
                                .font(.caption2)
                                .foregroundColor(.secondary)
                        } else {
                            HStack {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundColor(.green)
                                Text("Card automatically recognized")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                            
                            Text("Review and edit details if needed")
                                .font(.caption2)
                                .foregroundColor(.secondary)
                        }
                    }
                    .padding()
                    .background(editedCard.name == "Scanned Card" ? Color.orange.opacity(0.1) : Color.green.opacity(0.1))
                    .cornerRadius(8)
                    
                    // Action Buttons
                    VStack(spacing: 12) {
                        Button(action: {
                            addCardToCollection()
                        }) {
                            HStack {
                                Image(systemName: "plus.circle.fill")
                                Text("Add to Collection")
                            }
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(12)
                        }
                        
                        Button(action: {
                            showingManualEdit = true
                        }) {
                            HStack {
                                Image(systemName: "pencil")
                                Text("Edit Details")
                            }
                            .font(.headline)
                            .foregroundColor(.blue)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue.opacity(0.1))
                            .cornerRadius(12)
                        }
                        
                        Button(action: {
                            presentationMode.wrappedValue.dismiss()
                        }) {
                            Text("Cancel")
                                .font(.headline)
                                .foregroundColor(.red)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.red.opacity(0.1))
                                .cornerRadius(12)
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("Confirm Card")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        presentationMode.wrappedValue.dismiss()
                    }
                }
            }
            .onAppear {
                if let image = capturedImage {
                    imageProcessor.processCardImage(image) { _ in
                        // Image processing completed
                    }
                }
            }
            .sheet(isPresented: $showingManualEdit) {
                ManualEditView(card: $editedCard, detectedText: detectedText)
            }
            .alert("Card Added!", isPresented: $showingSuccess) {
                Button("OK") {
                    presentationMode.wrappedValue.dismiss()
                }
            } message: {
                Text("\(editedCard.name) has been added to your collection!")
            }
        }
    }
    
    private func addCardToCollection() {
        // Save the captured image locally if available
        var finalCard = editedCard
        if let image = capturedImage {
            if let imagePath = saveImageToDocuments(image, cardId: editedCard.id.uuidString) {
                finalCard = PokemonCard(
                    name: editedCard.name,
                    set: editedCard.set,
                    number: editedCard.number,
                    rarity: editedCard.rarity,
                    imageURL: editedCard.imageURL,
                    localImagePath: imagePath,
                    hp: editedCard.hp,
                    types: editedCard.types,
                    attacks: editedCard.attacks,
                    weaknesses: editedCard.weaknesses,
                    resistances: editedCard.resistances,
                    retreatCost: editedCard.retreatCost,
                    artist: editedCard.artist,
                    marketValue: editedCard.marketValue
                )
            }
        }
        
        cardCollection.addCard(finalCard)
        showingSuccess = true
    }
    
    private func saveImageToDocuments(_ image: UIImage, cardId: String) -> String? {
        guard let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
            return nil
        }
        
        let fileName = "card_\(cardId).jpg"
        let fileURL = documentsDirectory.appendingPathComponent(fileName)
        
        guard let imageData = image.jpegData(compressionQuality: 0.8) else {
            return nil
        }
        
        do {
            try imageData.write(to: fileURL)
            return fileName
        } catch {
            print("Failed to save image: \(error)")
            return nil
        }
    }
}

struct DetailRow: View {
    let label: String
    let value: String
    
    var body: some View {
        HStack {
            Text(label)
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            Spacer()
            
            Text(value)
                .font(.subheadline)
                .fontWeight(.medium)
        }
    }
}

#Preview {
    CameraView()
        .environmentObject(CardCollection())
        .environmentObject(ImageProcessor())
}

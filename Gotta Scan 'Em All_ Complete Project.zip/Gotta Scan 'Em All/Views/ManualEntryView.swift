//
//  ManualEntryView.swift
//  Gotta Scan 'Em All
//

import SwiftUI

struct ManualEntryView: View {

    /// Called when a card is manually added.
    let onSave: (PokemonCard) -> Void

    init(onSave: @escaping (PokemonCard) -> Void = { _ in }) {
        self.onSave = onSave
    }

    @Environment(\.dismiss) private var dismiss

    @State private var name: String = ""
    @State private var number: String = ""
    @State private var setName: String = ""

    @State private var isSearching: Bool = false
    @State private var searchResults: [PokemonTCGAPIService.PokemonTCGCard] = []
    @State private var selectedAPICard: PokemonTCGAPIService.PokemonTCGCard?
    @State private var errorMessage: String?

    private let api = PokemonTCGAPIService.shared

    var body: some View {
        NavigationView {
            VStack {
                Form {
                    Section(header: Text("Card Info")) {
                        TextField("Name", text: $name)
                        TextField("Number (e.g. 44)", text: $number)
                            .keyboardType(.numberPad)
                        TextField("Set (optional)", text: $setName)
                    }

                    Section(header: Text("Search Online")) {
                        Button {
                            runSearch()
                        } label: {
                            if isSearching {
                                ProgressView()
                            } else {
                                Text("Search Pokémon TCG API")
                            }
                        }
                        .disabled(isSearching || name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)

                        if !searchResults.isEmpty {
                            List {
                                ForEach(searchResults) { card in
                                    HStack {
                                        VStack(alignment: .leading) {
                                            Text(card.name)
                                                .font(.body)
                                            Text("\(card.set?.name ?? "Unknown Set") • \(card.number ?? "")")
                                                .font(.caption)
                                                .foregroundColor(.secondary)
                                        }
                                        Spacer()
                                        if selectedAPICard?.id == card.id {
                                            Image(systemName: "checkmark.circle.fill")
                                                .foregroundColor(.green)
                                        }
                                    }
                                    .contentShape(Rectangle())
                                    .onTapGesture {
                                        select(apiCard: card)
                                    }
                                }
                            }
                            .frame(minHeight: 150, maxHeight: 250)
                        }
                    }

                    if let errorMessage {
                        Section {
                            Text(errorMessage)
                                .foregroundColor(.red)
                                .font(.footnote)
                        }
                    }
                }

                Button {
                    saveCard()
                } label: {
                    Text("Save Card")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .padding()
            }
            .navigationTitle("Manual Entry")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
            }
        }
    }

    // MARK: - Actions

    private func runSearch() {
        let trimmedName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedName.isEmpty else { return }

        isSearching = true
        errorMessage = nil
        searchResults = []
        selectedAPICard = nil

        // ✅ FIX: Pass both name and number parameters
        let trimmedNumber = number.trimmingCharacters(in: .whitespacesAndNewlines)
        let numberToSearch = trimmedNumber.isEmpty ? nil : trimmedNumber
        
        api.searchCards(name: trimmedName, number: numberToSearch) { result in
            DispatchQueue.main.async {
                self.isSearching = false
                switch result {
                case .success(let cards):
                    self.searchResults = cards
                    if let first = cards.first {
                        self.select(apiCard: first)
                    }
                case .failure(let error):
                    self.errorMessage = "Search failed: \(error.localizedDescription)"
                }
            }
        }
    }

    private func select(apiCard: PokemonTCGAPIService.PokemonTCGCard) {
        selectedAPICard = apiCard
        name = apiCard.name
        number = apiCard.number ?? ""
        setName = apiCard.set?.name ?? ""
    }

    private func saveCard() {
        let card: PokemonCard

        if let apiCard = selectedAPICard {
            card = makePokemonCard(from: apiCard)
        } else {
            // Minimal fallback card using manual fields
            card = PokemonCard(
                name: name.trimmingCharacters(in: .whitespacesAndNewlines),
                set: setName.trimmingCharacters(in: .whitespacesAndNewlines),
                number: number.trimmingCharacters(in: .whitespacesAndNewlines),
                rarity: .common,
                hp: nil,
                types: [],
                marketValue: nil
            )
        }

        onSave(card)
        dismiss()
    }

    // MARK: - Mapping helper

    private func makePokemonCard(from apiCard: PokemonTCGAPIService.PokemonTCGCard) -> PokemonCard {

        func mapRarity(_ raw: String?) -> CardRarity {
            guard let r = raw?.lowercased() else { return .common }
            switch r {
            case "common":
                return .common
            case "uncommon":
                return .uncommon
            case "rare":
                return .rare
            case "rare holo", "rare holofoil", "holo rare", "holo":
                return .rareHolo
            case "ultra rare":
                return .ultraRare
            case "secret rare":
                return .secretRare
            case "promo":
                return .promo
            default:
                if r.contains("illustration") {
                    return .illustration
                }
                return .common
            }
        }

        return PokemonCard(
            name: apiCard.name,
            set: apiCard.set?.name ?? "",
            number: apiCard.number ?? "",
            rarity: mapRarity(apiCard.rarity),
            hp: nil,
            types: [],
            marketValue: nil
        )
    }
}

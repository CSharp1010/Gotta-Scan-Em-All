//
//  StatisticsView.swift
//  Gotta Scan 'Em All
//

import SwiftUI

struct StatisticsView: View {
    @EnvironmentObject var cardCollection: CardCollection

    // MARK: - Computed Stats

    private var totalCards: Int {
        cardCollection.cards.count
    }

    private var totalValue: Double {
        cardCollection.cards
            .compactMap { $0.marketValue }
            .reduce(0, +)
    }

    private var averageValue: Double {
        guard totalCards > 0 else { return 0 }
        return totalValue / Double(totalCards)
    }

    private var cardsByRarity: [(label: String, count: Int)] {
        var counts: [String: Int] = [:]

        for card in cardCollection.cards {
            let key = card.rarity.rawValue.capitalized
            counts[key, default: 0] += 1
        }

        return counts
            .sorted { $0.key < $1.key }
            .map { (label: $0.key, count: $0.value) }
    }

    private var cardsByType: [(label: String, count: Int)] {
        var counts: [String: Int] = [:]

        for card in cardCollection.cards {
            for t in card.types {
                let key = t.rawValue
                counts[key, default: 0] += 1
            }
        }

        return counts
            .sorted { $0.key < $1.key }
            .map { (label: $0.key, count: $0.value) }
    }

    private var topValuableCards: [PokemonCard] {
        cardCollection.cards
            .sorted { ($0.marketValue ?? 0) > ($1.marketValue ?? 0) }
            .prefix(5)
            .map { $0 }
    }

    // MARK: - Body

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 24) {

                    // MARK: Summary Cards
                    summarySection

                    // MARK: Rarity Breakdown
                    if !cardsByRarity.isEmpty {
                        statSection(title: "By Rarity") {
                            ForEach(cardsByRarity, id: \.label) { item in
                                HStack {
                                    Text(item.label)
                                    Spacer()
                                    Text("\(item.count)")
                                        .fontWeight(.semibold)
                                }
                                .padding(.vertical, 4)
                            }
                        }
                    }

                    // MARK: Type Breakdown
                    if !cardsByType.isEmpty {
                        statSection(title: "By Type") {
                            ForEach(cardsByType, id: \.label) { item in
                                HStack {
                                    Text(item.label)
                                    Spacer()
                                    Text("\(item.count)")
                                        .fontWeight(.semibold)
                                }
                                .padding(.vertical, 4)
                            }
                        }
                    }

                    // MARK: Top Valuable
                    if !topValuableCards.isEmpty {
                        statSection(title: "Most Valuable Cards") {
                            ForEach(topValuableCards, id: \.id) { card in
                                HStack {
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(card.name)
                                            .font(.headline)
                                        Text("\(card.set) • \(card.number)")
                                            .font(.caption)
                                            .foregroundColor(.secondary)
                                    }
                                    Spacer()
                                    if let price = card.marketValue {
                                        Text(String(format: "$%.2f", price))
                                            .fontWeight(.semibold)
                                    }
                                }
                                .padding(.vertical, 4)
                            }
                        }
                    }

                    if cardCollection.cards.isEmpty {
                        Text("No cards in your collection yet.\nAdd some cards to see statistics!")
                            .multilineTextAlignment(.center)
                            .foregroundColor(.secondary)
                            .padding(.top, 40)
                    }
                }
                .padding()
            }
            .navigationTitle("Statistics")
        }
    }

    // MARK: - Subviews

    private var summarySection: some View {
        HStack(spacing: 16) {
            summaryCard(
                title: "Total Cards",
                value: "\(totalCards)"
            )
            summaryCard(
                title: "Total Value",
                value: String(format: "$%.2f", totalValue)
            )
            summaryCard(
                title: "Avg. Value",
                value: totalCards > 0
                    ? String(format: "$%.2f", averageValue)
                    : "$0.00"
            )
        }
    }

    private func summaryCard(title: String, value: String) -> some View {
        VStack(spacing: 6) {
            Text(value)
                .font(.headline)
            Text(title)
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(14)
        .shadow(color: Color.black.opacity(0.06), radius: 6, x: 0, y: 2)
    }

    private func statSection<Content: View>(
        title: String,
        @ViewBuilder content: () -> Content
    ) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.headline)
            VStack(alignment: .leading, spacing: 4) {
                content()
            }
            .padding()
            .background(Color(.systemBackground))
            .cornerRadius(14)
            .shadow(color: Color.black.opacity(0.04), radius: 4, x: 0, y: 1)
        }
    }
}

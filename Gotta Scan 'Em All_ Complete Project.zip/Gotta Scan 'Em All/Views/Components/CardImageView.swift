//
//  CardImageView.swift
//  Gotta Scan 'Em All
//
//  Created by Jersain Hermosillo on 9/8/25.
//  Updated 11/29/25 by Casey S. 

import SwiftUI
import UIKit

struct CardImageView: View {
    let card: PokemonCard
    let aspectRatio: CGFloat
    let cornerRadius: CGFloat
    let showPlaceholder: Bool

    init(
        card: PokemonCard,
        aspectRatio: CGFloat = 0.7,
        cornerRadius: CGFloat = 8,
        showPlaceholder: Bool = true
    ) {
        self.card = card
        self.aspectRatio = aspectRatio
        self.cornerRadius = cornerRadius
        self.showPlaceholder = showPlaceholder
    }

    var body: some View {
        Group {
            // 1️⃣ Try online image first if available
            if let imageURL = card.imageURL, !imageURL.isEmpty {
                AsyncImage(url: URL(string: imageURL), transaction: Transaction(animation: nil)) { phase in
                    switch phase {
                    case .success(let image):
                        image
                            .resizable()
                            .aspectRatio(contentMode: .fit)

                    case .failure(let error):
                        CardPlaceholderView(showPlaceholder: showPlaceholder)
                            .onAppear {
                                print("Image loading failed for \(card.name): \(error)")
                            }

                    case .empty:
                        VStack {
                            ProgressView()
                                .scaleEffect(0.8)
                            Text("Loading...")
                                .font(.caption2)
                                .foregroundColor(.secondary)
                        }

                    @unknown default:
                        CardPlaceholderView(showPlaceholder: showPlaceholder)
                    }
                }

            // 2️⃣ If no remote image, try local asset or saved file
            } else if let localPath = card.localImagePath, !localPath.isEmpty {

                // 🔹 First, look for an image in Assets.xcassets
                if let assetImage = UIImage(named: localPath) {
                    Image(uiImage: assetImage)
                        .resizable()
                        .aspectRatio(contentMode: .fit)

                // 🔹 If not in assets, check Documents directory
                } else if let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
                    let fileURL = documentsDirectory.appendingPathComponent(localPath)
                    if
                        let imageData = try? Data(contentsOf: fileURL),
                        let uiImage = UIImage(data: imageData)
                    {
                        Image(uiImage: uiImage)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                    } else {
                        CardPlaceholderView(showPlaceholder: showPlaceholder)
                            .onAppear {
                                print("⚠️ Local image not found for \(localPath)")
                            }
                    }
                } else {
                    CardPlaceholderView(showPlaceholder: showPlaceholder)
                }

            // 3️⃣ Fallback placeholder
            } else {
                CardPlaceholderView(showPlaceholder: showPlaceholder)
                    .onAppear {
                        print("No image URL or local path for card: \(card.name)")
                    }
            }
        }
        .aspectRatio(aspectRatio, contentMode: .fit)
        .cornerRadius(cornerRadius)
    }
}

// MARK: - Placeholder View
struct CardPlaceholderView: View {
    let showPlaceholder: Bool

    var body: some View {
        RoundedRectangle(cornerRadius: 8)
            .fill(Color(UIColor.systemGray5))
            .overlay(
                VStack {
                    if showPlaceholder {
                        Image(systemName: "photo")
                            .font(.title)
                            .foregroundColor(.gray)
                        Text("Card Image")
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                }
            )
    }
}

#Preview {
    VStack(spacing: 20) {
        CardImageView(card: PokemonCard(
            name: "Pikachu",
            set: "Base Set",
            number: "58/102",
            rarity: .common,
            imageURL: "https://images.pokemontcg.io/base1/58_hires.png",
            hp: 40,
            types: [.lightning],
            marketValue: 5.99
        ))
        .frame(height: 200)

        CardImageView(card: PokemonCard(
            name: "Pikachu",
            set: "Rising Rivals",
            number: "112/111",
            rarity: .secretRare,
            imageURL: nil,
            localImagePath: "pikachu_112_111"
        ))
        .frame(height: 200)
    }
    .padding()
}


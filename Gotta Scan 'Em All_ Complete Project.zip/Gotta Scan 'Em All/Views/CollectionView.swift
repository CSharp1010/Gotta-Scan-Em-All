//
//  CollectionView.swift
//  Gotta Scan 'Em All
//

import SwiftUI

struct CollectionView: View {
    @EnvironmentObject var cardCollection: CardCollection
    @State private var searchText: String = ""

    // MARK: - Filtering

    private var filteredCards: [PokemonCard] {
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()

        guard !query.isEmpty else {
            return cardCollection.cards
        }

        return cardCollection.cards.filter { card in
            let name = card.name.lowercased()
            let setName = card.set.lowercased()
            let number = card.number.lowercased()

            return name.contains(query) ||
                   setName.contains(query) ||
                   number.contains(query)
        }
    }

    // MARK: - Body

    var body: some View {
        NavigationView {
            Group {
                if filteredCards.isEmpty {
                    VStack(spacing: 12) {
                        Image(systemName: "tray")
                            .font(.system(size: 40))
                            .foregroundColor(.secondary)

                        if searchText.isEmpty {
                            Text("No cards in your collection yet.")
                                .font(.headline)
                            Text("Scan a card or add one manually to get started.")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal)
                        } else {
                            Text("No results for \"\(searchText)\"")
                                .font(.headline)
                            Text("Try searching by card name, set, or number.")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal)
                        }
                    }
                    .padding()
                } else {
                    List {
                        ForEach(filteredCards, id: \.id) { card in
                            NavigationLink(destination: CardDetailView(card: card)) {
                                HStack(spacing: 12) {
                                    // Card thumbnail
                                    CardImageView(
                                        card: card,
                                        aspectRatio: 0.7,
                                        cornerRadius: 8,
                                        showPlaceholder: true
                                    )
                                    .frame(width: 60, height: 90)

                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(card.name)
                                            .font(.headline)

                                        Text("\(card.set) • \(card.number)")
                                            .font(.caption)
                                            .foregroundColor(.secondary)

                                        if let price = card.marketValue {
                                            Text(String(format: "$%.2f", price))
                                                .font(.caption)
                                                .foregroundColor(.green)
                                        }
                                    }

                                    Spacer()
                                }
                                .padding(.vertical, 4)
                            }
                        }
                    }
                    .listStyle(.plain)
                }
            }
            .navigationTitle("Collection")
            .searchable(text: $searchText, prompt: "Search by name, set, or number")
        }
    }
}


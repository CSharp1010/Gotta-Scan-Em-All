//
//  CardDetailView.swift
//  Gotta Scan 'Em All
//
//  Created by Jersain Hermosillo on 9/8/25.
//

import SwiftUI

struct CardDetailView: View {
    let card: PokemonCard
    @EnvironmentObject var cardCollection: CardCollection
    @State private var showingDeleteAlert = false
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // Card Image
                CardImageView(card: card)
                    .aspectRatio(0.7, contentMode: .fit)
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .padding(.horizontal)
                
                // Card Information
                VStack(alignment: .leading, spacing: 16) {
                    // Header
                    VStack(alignment: .leading, spacing: 8) {
                        Text(card.name)
                            .font(.largeTitle)
                            .fontWeight(.bold)
                        
                        HStack {
                            Text(card.set)
                                .font(.headline)
                                .foregroundColor(.secondary)
                            
                            Spacer()
                            
                            RarityBadge(rarity: card.rarity)
                        }
                        
                        Text("Card #\(card.number)")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                    
                    Divider()
                    
                    // Stats Section
                    if card.hp != nil || !card.types.isEmpty {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Stats")
                                .font(.headline)
                            
                            if let hp = card.hp {
                                StatRow(icon: "heart.fill", label: "HP", value: "\(hp)", color: .red)
                            }
                            
                            if !card.types.isEmpty {
                                StatRow(
                                    icon: "sparkles",
                                    label: "Type",
                                    value: card.types.map { $0.rawValue }.joined(separator: ", "),
                                    color: .blue
                                )
                            }
                            
                            if let retreatCost = card.retreatCost {
                                StatRow(
                                    icon: "arrow.left.arrow.right",
                                    label: "Retreat Cost",
                                    value: "\(retreatCost)",
                                    color: .gray
                                )
                            }
                        }
                    }
                    
                    // Attacks Section
                    if let attacks = card.attacks, !attacks.isEmpty {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Attacks")
                                .font(.headline)
                            
                            ForEach(attacks, id: \.name) { attack in
                                AttackRow(attack: attack)
                            }
                        }
                    }
                    
                    // Weaknesses and Resistances
                    if let weaknesses = card.weaknesses, !weaknesses.isEmpty {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Weaknesses")
                                .font(.headline)
                            
                            ForEach(weaknesses, id: \.type) { weakness in
                                WeaknessResistanceRow(
                                    type: weakness.type,
                                    value: weakness.value,
                                    isWeakness: true
                                )
                            }
                        }
                    }
                    
                    if let resistances = card.resistances, !resistances.isEmpty {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Resistances")
                                .font(.headline)
                            
                            ForEach(resistances, id: \.type) { resistance in
                                WeaknessResistanceRow(
                                    type: resistance.type,
                                    value: resistance.value,
                                    isWeakness: false
                                )
                            }
                        }
                    }
                    
                    // Additional Info
                    VStack(alignment: .leading, spacing: 8) {
                        if let artist = card.artist {
                            InfoRow(label: "Artist", value: artist)
                        }
                        
                        if let value = card.marketValue {
                            InfoRow(
                                label: "Market Value",
                                value: String(format: "$%.2f", value)
                            )
                        }
                        
                        InfoRow(
                            label: "Date Added",
                            value: card.dateAdded.formatted(
                                date: .abbreviated,
                                time: .omitted
                            )
                        )
                    }
                }
                .padding()
                .background(Color(.systemBackground))
                .cornerRadius(16)
                .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: 1)
                .padding(.horizontal)
            }
        }
        .navigationTitle(card.name)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button(action: {
                    showingDeleteAlert = true
                }) {
                    Image(systemName: "trash")
                        .foregroundColor(.red)
                }
            }
        }
        .alert("Remove Card", isPresented: $showingDeleteAlert) {
            Button("Cancel", role: .cancel) { }
            Button("Remove", role: .destructive) {
                cardCollection.removeCard(card)
            }
        } message: {
            Text("Are you sure you want to remove \(card.name) from your collection?")
        }
    }
}

struct StatRow: View {
    let icon: String
    let label: String
    let value: String
    let color: Color
    
    var body: some View {
        HStack {
            Image(systemName: icon)
                .foregroundColor(color)
                .frame(width: 20)
            
            Text(label)
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            Spacer()
            
            Text(value)
                .font(.subheadline)
                .fontWeight(.medium)
        }
    }
}

struct AttackRow: View {
    let attack: Attack
    
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(attack.name)
                    .font(.subheadline)
                    .fontWeight(.semibold)
                
                Spacer()
                
                if let damage = attack.damage {
                    Text(damage)
                        .font(.subheadline)
                        .fontWeight(.bold)
                        .foregroundColor(.red)
                }
            }
            
            if let text = attack.text {
                Text(text)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            if !attack.cost.isEmpty {
                HStack {
                    Text("Cost:")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    HStack(spacing: 2) {
                        ForEach(attack.cost, id: \.self) { type in
                            Image(systemName: type.icon)
                                .font(.caption)
                                .foregroundColor(type.color)
                        }
                    }
                }
            }
        }
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(8)
    }
}

struct WeaknessResistanceRow: View {
    let type: PokemonType
    let value: String
    let isWeakness: Bool
    
    var body: some View {
        HStack {
            Image(systemName: type.icon)
                .foregroundColor(type.color)
                .frame(width: 20)
            
            Text(type.rawValue)
                .font(.subheadline)
            
            Spacer()
            
            Text(value)
                .font(.subheadline)
                .fontWeight(.medium)
                .foregroundColor(isWeakness ? .red : .green)
        }
    }
}

struct InfoRow: View {
    let label: String
    let value: String
    
    var body: some View {
        HStack {
            Text(label)
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            Spacer()
            
            Text(value)
                .font(.subheadline)
                .fontWeight(.medium)
        }
    }
}

// MARK: - Rarity Badge

struct RarityBadge: View {
    let rarity: CardRarity

    private var backgroundColor: Color {
        switch rarity {
        case .common:
            return Color.gray.opacity(0.2)
        case .uncommon:
            return Color.green.opacity(0.2)
        case .rare, .rareHolo:
            return Color.blue.opacity(0.2)
        case .ultraRare, .secretRare, .illustration:
            return Color.purple.opacity(0.2)
        case .promo:
            return Color.orange.opacity(0.2)
        }
    }

    var body: some View {
        Text(rarity.rawValue.capitalized)
            .font(.caption2)
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .background(backgroundColor)
            .foregroundColor(.primary)
            .clipShape(Capsule())
    }
}

#Preview {
    NavigationView {
        CardDetailView(card: PokemonCard(
            name: "Pikachu",
            set: "Base Set",
            number: "58/102",
            rarity: .common,
            hp: 40,
            types: [.lightning],
            attacks: [
                Attack(
                    name: "Thunder Shock",
                    cost: [.lightning],
                    damage: "10",
                    text: "Flip a coin. If heads, the Defending Pokémon is now Paralyzed."
                )
            ],
            marketValue: 5.99
        ))
    }
    .environmentObject(CardCollection())
}


//
//  SettingsView.swift
//  Gotta Scan 'Em All
//

import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var cardCollection: CardCollection

    // App theme (from your AppTheme enum)
    @AppStorage("appTheme") private var storedTheme: String = AppTheme.system.rawValue

    @State private var showClearAlert = false

    // MARK: - Computed stats for display only

    private var totalCards: Int {
        cardCollection.cards.count
    }

    private var totalValue: Double {
        cardCollection.cards
            .compactMap { $0.marketValue }
            .reduce(0, +)
    }

    // MARK: - Body

    var body: some View {
        NavigationView {
            Form {
                // MARK: Appearance
                Section(header: Text("Appearance")) {
                    Picker("App Theme", selection: $storedTheme) {
                        ForEach(AppTheme.allCases) { theme in
                            Text(theme.label)
                                .tag(theme.rawValue)
                        }
                    }
                }

                // MARK: Collection Info
                Section(header: Text("Collection")) {
                    HStack {
                        Text("Total Cards")
                        Spacer()
                        Text("\(totalCards)")
                            .foregroundColor(.secondary)
                    }

                    HStack {
                        Text("Estimated Value")
                        Spacer()
                        Text(String(format: "$%.2f", totalValue))
                            .foregroundColor(.secondary)
                    }

                    Button(role: .destructive) {
                        showClearAlert = true
                    } label: {
                        Text("Clear Collection")
                    }
                }

                // MARK: About
                Section(header: Text("About")) {
                    HStack {
                        Text("App")
                        Spacer()
                        Text("Gotta Scan 'Em All")
                            .foregroundColor(.secondary)
                    }

                    HStack {
                        Text("Version")
                        Spacer()
                        Text("1.0.0")
                            .foregroundColor(.secondary)
                    }

                    VStack(alignment: .leading, spacing: 4) {
                        Text("How it works")
                            .font(.subheadline)
                        Text("Scan Pokémon cards or pick photos from your library. The app uses OCR and the Pokémon TCG API to identify cards and estimate their market value.")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    .padding(.top, 4)
                }
            }
            .navigationTitle("Settings")
            .alert("Clear Collection", isPresented: $showClearAlert) {
                Button("Cancel", role: .cancel) { }
                Button("Clear", role: .destructive) {
                    // Remove all cards from the collection
                    cardCollection.cards.removeAll()
                }
            } message: {
                Text("This will remove all cards from your collection. This action cannot be undone.")
            }
        }
    }
}
// Legacy wrapper to satisfy existing references
struct AppSettingsView: View {
    var body: some View {
        SettingsView()
    }
}


//
//  CameraManager.swift
//  Gotta Scan 'Em All
//
//  Created by Assistant on 11/24/25.
//

import Foundation
import AVFoundation
import UIKit
import Combine

final class CameraManager: NSObject, ObservableObject {
    enum CameraError: Error, Equatable {
        case notAuthorized
        case configurationFailed
        case captureFailed
        case unknown
    }

    @Published var isAuthorized: Bool = false
    @Published var error: CameraError? = nil
    @Published var capturedImage: UIImage? = nil

    let session = AVCaptureSession()

    private let sessionQueue = DispatchQueue(label: "camera.session.queue")
    private var photoOutput = AVCapturePhotoOutput()
    private var videoDeviceInput: AVCaptureDeviceInput?

    override init() {
        super.init()
        checkAuthorization()
    }

    private func checkAuthorization() {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            self.isAuthorized = true
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { granted in
                DispatchQueue.main.async {
                    self.isAuthorized = granted
                    if !granted {
                        self.error = .notAuthorized
                    }
                }
            }
        case .denied, .restricted:
            self.isAuthorized = false
            self.error = .notAuthorized
        @unknown default:
            self.isAuthorized = false
            self.error = .unknown
        }
    }

    func startSession() {
        guard isAuthorized else { return }
        sessionQueue.async {
            if !self.session.isRunning {
                do {
                    try self.configureSessionIfNeeded()
                    self.session.startRunning()
                } catch {
                    DispatchQueue.main.async { self.error = .configurationFailed }
                }
            }
        }
    }

    func stopSession() {
        sessionQueue.async {
            if self.session.isRunning {
                self.session.stopRunning()
            }
        }
    }

    private func configureSessionIfNeeded() throws {
        guard session.inputs.isEmpty && session.outputs.isEmpty else { return }

        session.beginConfiguration()
        session.sessionPreset = .photo

        // Select default camera (back)
        guard let videoDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) ??
                AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front) else {
            session.commitConfiguration()
            throw CameraError.configurationFailed
        }

        do {
            let videoInput = try AVCaptureDeviceInput(device: videoDevice)
            if session.canAddInput(videoInput) {
                session.addInput(videoInput)
                self.videoDeviceInput = videoInput
            } else {
                session.commitConfiguration()
                throw CameraError.configurationFailed
            }
        } catch {
            session.commitConfiguration()
            throw CameraError.configurationFailed
        }

        photoOutput = AVCapturePhotoOutput()
        photoOutput.isHighResolutionCaptureEnabled = true
        if session.canAddOutput(photoOutput) {
            session.addOutput(photoOutput)
        } else {
            session.commitConfiguration()
            throw CameraError.configurationFailed
        }

        session.commitConfiguration()
    }

    func switchCamera() {
        sessionQueue.async {
            guard let currentInput = self.videoDeviceInput else { return }
            let currentPosition = currentInput.device.position
            let preferredPosition: AVCaptureDevice.Position = currentPosition == .back ? .front : .back

            guard let newDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: preferredPosition) else { return }

            do {
                let newInput = try AVCaptureDeviceInput(device: newDevice)
                self.session.beginConfiguration()
                self.session.removeInput(currentInput)
                if self.session.canAddInput(newInput) {
                    self.session.addInput(newInput)
                    self.videoDeviceInput = newInput
                } else {
                    // Re-add old input if failed
                    if self.session.canAddInput(currentInput) {
                        self.session.addInput(currentInput)
                    }
                }
                self.session.commitConfiguration()
            } catch {
                DispatchQueue.main.async { self.error = .configurationFailed }
            }
        }
    }

    func capturePhoto() {
        sessionQueue.async {
            // Choose a supported codec: prefer HEVC if available, else JPEG
            let preferredCodec: AVVideoCodecType
            if self.photoOutput.availablePhotoCodecTypes.contains(.hevc) {
                preferredCodec = .hevc
            } else if self.photoOutput.availablePhotoCodecTypes.contains(.jpeg) {
                preferredCodec = .jpeg
            } else if let first = self.photoOutput.availablePhotoCodecTypes.first {
                preferredCodec = first
            } else {
                // Fallback: no available codecs, report error
                DispatchQueue.main.async { self.error = .captureFailed }
                return
            }

            // Create settings with the chosen codec using the `format` initializer
            let settings = AVCapturePhotoSettings(format: [AVVideoCodecKey: preferredCodec])
            settings.isHighResolutionPhotoEnabled = true

            // If flash is supported on the current device, keep it off by default
            if let device = self.videoDeviceInput?.device, device.isFlashAvailable {
                settings.flashMode = .off
            }

            self.photoOutput.capturePhoto(with: settings, delegate: self)
        }
    }
}

extension CameraManager: AVCapturePhotoCaptureDelegate {
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        if let error = error {
            DispatchQueue.main.async { self.error = .captureFailed }
            print("Photo capture error: \(error)")
            return
        }
        guard let data = photo.fileDataRepresentation(), let image = UIImage(data: data) else {
            DispatchQueue.main.async { self.error = .captureFailed }
            return
        }
        DispatchQueue.main.async {
            self.capturedImage = image
        }
    }
}

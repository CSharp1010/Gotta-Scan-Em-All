//
//  ManualEditView.swift
//  Gotta Scan 'Em All
//

import SwiftUI

struct ManualEditView: View {
    @Binding var card: PokemonCard
    let detectedText: [String]

    @Environment(\.dismiss) private var dismiss

    @State private var name: String
    @State private var setName: String
    @State private var number: String
    @State private var rarity: CardRarity
    @State private var hpString: String
    @State private var artist: String
    @State private var marketValueString: String

    init(card: Binding<PokemonCard>, detectedText: [String] = []) {
        self._card = card
        self.detectedText = detectedText

        _name = State(initialValue: card.wrappedValue.name)
        _setName = State(initialValue: card.wrappedValue.set)
        _number = State(initialValue: card.wrappedValue.number)
        _rarity = State(initialValue: card.wrappedValue.rarity)
        _hpString = State(initialValue: card.wrappedValue.hp.map { String($0) } ?? "")
        _artist = State(initialValue: card.wrappedValue.artist ?? "")
        if let value = card.wrappedValue.marketValue {
            _marketValueString = State(initialValue: String(format: "%.2f", value))
        } else {
            _marketValueString = State(initialValue: "")
        }
    }

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Basic Info")) {
                    TextField("Name", text: $name)
                    TextField("Set", text: $setName)
                    TextField("Number", text: $number)
                }

                Section(header: Text("Rarity & Stats")) {
                    Picker("Rarity", selection: $rarity) {
                        Text("Common").tag(CardRarity.common)
                        Text("Uncommon").tag(CardRarity.uncommon)
                        Text("Rare").tag(CardRarity.rare)
                        Text("Rare Holo").tag(CardRarity.rareHolo)
                        Text("Ultra Rare").tag(CardRarity.ultraRare)
                        Text("Secret Rare").tag(CardRarity.secretRare)
                        Text("Promo").tag(CardRarity.promo)
                        Text("Illustration").tag(CardRarity.illustration)
                    }
                    TextField("HP", text: $hpString)
                        .keyboardType(.numberPad)
                    TextField("Artist", text: $artist)
                    TextField("Estimated Value ($)", text: $marketValueString)
                        .keyboardType(.decimalPad)
                }

                if !detectedText.isEmpty {
                    Section(header: Text("Scanned Text (reference)")) {
                        ScrollView {
                            VStack(alignment: .leading, spacing: 4) {
                                ForEach(detectedText, id: \.self) { line in
                                    Text(line)
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }
                            }
                        }
                        .frame(maxHeight: 120)
                    }
                }
            }
            .navigationTitle("Edit Card")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") { applyChangesAndDismiss() }
                }
            }
        }
    }

    private func applyChangesAndDismiss() {
        let trimmedName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedSet = setName.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedNumber = number.trimmingCharacters(in: .whitespacesAndNewlines)

        let hpValue: Int? = Int(hpString.trimmingCharacters(in: .whitespacesAndNewlines))
        let artistValue: String? = {
            let t = artist.trimmingCharacters(in: .whitespacesAndNewlines)
            return t.isEmpty ? nil : t
        }()

        let mvTrimmed = marketValueString.trimmingCharacters(in: .whitespacesAndNewlines)
        let mvValue: Double? = Double(mvTrimmed)

        // ✅ Match the initializer order you use elsewhere (name, set, number, rarity, imageURL, localImagePath, hp, types, attacks, weaknesses, resistances, retreatCost, artist, marketValue)
        card = PokemonCard(
            name: trimmedName.isEmpty ? card.name : trimmedName,
            set: trimmedSet.isEmpty ? card.set : trimmedSet,
            number: trimmedNumber.isEmpty ? card.number : trimmedNumber,
            rarity: rarity,
            imageURL: card.imageURL,
            localImagePath: card.localImagePath,
            hp: hpValue,
            types: card.types,
            attacks: card.attacks,
            weaknesses: card.weaknesses,
            resistances: card.resistances,
            retreatCost: card.retreatCost,
            artist: artistValue ?? card.artist,
            marketValue: mvValue ?? card.marketValue
        )

        dismiss()
    }
}


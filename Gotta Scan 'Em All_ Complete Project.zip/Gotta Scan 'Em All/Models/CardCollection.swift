//
//  CardCollection.swift
//  Gotta Scan 'Em All
//

import Foundation
import SwiftUI

@MainActor
final class CardCollection: ObservableObject {
    @Published var cards: [PokemonCard] = [] {
        didSet { save() }
    }

    private let storageKey = "pokemonCardCollection"

    init() {
        load()
    }

    // MARK: - Public API

    func addCard(_ card: PokemonCard) {
        // prevent duplicates based on name + number
        if !cards.contains(where: { $0.name == card.name && $0.number == card.number }) {
            cards.append(card)
        }
    }

    func removeCard(_ card: PokemonCard) {
        cards.removeAll { $0.id == card.id }
    }

    func removeCards(at offsets: IndexSet) {
        cards.remove(atOffsets: offsets)
    }

    func clearAll() {
        cards.removeAll()
        UserDefaults.standard.removeObject(forKey: storageKey)
    }

    // MARK: - Statistics

    var totalCards: Int {
        cards.count
    }

    var totalMarketValue: Double {
        cards.compactMap { $0.marketValue }.reduce(0, +)
    }

    // MARK: - Persistence

    private func save() {
        do {
            let data = try JSONEncoder().encode(cards)
            UserDefaults.standard.set(data, forKey: storageKey)
        } catch {
            print("❌ Failed to save card collection: \(error)")
        }
    }

    private func load() {
        guard let data = UserDefaults.standard.data(forKey: storageKey) else { return }

        do {
            let decoded = try JSONDecoder().decode([PokemonCard].self, from: data)
            self.cards = decoded
            print("✅ Loaded \(decoded.count) saved cards from UserDefaults")
        } catch {
            print("❌ Failed to decode saved cards: \(error)")
            self.cards = []
        }
    }
}


//
//  SampleData.swift
//  Gotta Scan 'Em All
//

import Foundation
import SwiftUI

/// Sample cards and preview collection used by SwiftUI previews.
/// Marked @MainActor so we can safely call CardCollection.addCard.
@MainActor
enum SampleData {

    /// A ready-to-use preview collection for SwiftUI previews
    static let previewCollection: CardCollection = {
        let collection = CardCollection()

        // Example sample cards – tweak to match your app if needed
        let pikachu = PokemonCard(
            name: "Pikachu",
            set: "Stormfront",
            number: "112/111",
            rarity: .common,
            imageURL: nil,
            localImagePath: nil,
            hp: 40,
            types: [.lightning],
            attacks: [],
            weaknesses: [],
            resistances: [],
            retreatCost: 1,
            artist: "Mitsuhiro Arita",
            marketValue: 5.00
        )

        let bulbasaur = PokemonCard(
            name: "Bulbasaur",
            set: "Base Set",
            number: "44/102",
            rarity: .common,
            imageURL: nil,
            localImagePath: nil,
            hp: 40,
            types: [.grass],
            attacks: [],
            weaknesses: [],
            resistances: [],
            retreatCost: 1,
            artist: "Mitsuhiro Arita",
            marketValue: 3.50
        )

        let mewtwo = PokemonCard(
            name: "Mewtwo",
            set: "Scarlet & Violet 151",
            number: "150/165",
            rarity: .rare,
            imageURL: nil,
            localImagePath: nil,
            hp: 130,
            types: [.psychic],
            attacks: [],
            weaknesses: [],
            resistances: [],
            retreatCost: 2,
            artist: "AKIRA EGAWA",
            marketValue: 15.00
        )

        collection.addCard(pikachu)
        collection.addCard(bulbasaur)
        collection.addCard(mewtwo)

        return collection
    }()
}


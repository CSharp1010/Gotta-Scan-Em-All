//
//  Gotta_Scan__Em_AllApp.swift
//  Gotta Scan 'Em All
//
//  Created by Jersain Hermosillo on 9/8/25.
//

import SwiftUI

@main
struct GottaScanEmAllApp: App {
    @StateObject private var cardCollection = CardCollection()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(cardCollection)
        }
    }
}



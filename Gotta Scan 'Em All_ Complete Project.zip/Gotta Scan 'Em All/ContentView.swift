//
//  ContentView.swift
//  Gotta Scan 'Em All
//
//  Created by Jersain Hermosillo on 9/8/25.
//

import SwiftUI

struct ContentView: View {
    @StateObject private var cardCollection = CardCollection()
    @AppStorage("appTheme") private var appThemeRawValue: String = AppTheme.system.rawValue

    private var appTheme: AppTheme {
        AppTheme(rawValue: appThemeRawValue) ?? .system
    }
    
    var body: some View {
        TabView {
            ScannerView()
                .environmentObject(cardCollection)
                .tabItem {
                    Image(systemName: "camera.viewfinder")
                    Text("Scanner")
                }
            
            CollectionView()
                .environmentObject(cardCollection)
                .tabItem {
                    Image(systemName: "square.grid.3x3")
                    Text("Collection")
                }
            
            StatisticsView()
                .environmentObject(cardCollection)
                .tabItem {
                    Image(systemName: "chart.bar.fill")
                    Text("Stats")
                }
            
            AppSettingsView()
                .environmentObject(cardCollection)
                .tabItem {
                    Image(systemName: "gear")
                    Text("Settings")
                }
        }
        .accentColor(.blue)
        .preferredColorScheme(appTheme.colorScheme)
    }
}

#Preview {
    ContentView()
}

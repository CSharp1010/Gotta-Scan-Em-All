#!/usr/bin/env python3
"""
Generate Pokémon-themed app icon for Gotta Scan 'Em All
Creates a Poké Ball with camera lens design
"""

from PIL import Image, ImageDraw, ImageFont
import os

def create_pokemon_app_icon(size=1024):
    """Create a Pokémon-themed app icon"""
    
    # Create image with transparent background
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Calculate dimensions
    center = size // 2
    radius = int(size * 0.45)  # Poké Ball radius
    
    # Background gradient (blue to darker blue)
    for i in range(radius):
        alpha = int(255 * (1 - i / radius))
        color = (30, 144, 255, alpha)  # Dodger blue
        draw.ellipse([center - i, center - i, center + i, center + i], 
                    outline=color, width=2)
    
    # Poké Ball base (white)
    draw.ellipse([center - radius, center - radius, center + radius, center + radius], 
                fill=(255, 255, 255, 255), outline=(0, 0, 0, 255), width=4)
    
    # Poké Ball top half (red)
    draw.ellipse([center - radius, center - radius, center + radius, center + radius], 
                fill=(220, 20, 60, 255), outline=(0, 0, 0, 255), width=4)
    
    # Poké Ball center line
    line_width = max(4, size // 64)
    draw.rectangle([center - radius, center - line_width//2, 
                   center + radius, center + line_width//2], 
                  fill=(0, 0, 0, 255))
    
    # Center button (camera lens style)
    button_radius = int(radius * 0.25)
    draw.ellipse([center - button_radius, center - button_radius, 
                 center + button_radius, center + button_radius], 
                fill=(50, 50, 50, 255), outline=(0, 0, 0, 255), width=3)
    
    # Camera lens inner circle
    inner_radius = int(button_radius * 0.6)
    draw.ellipse([center - inner_radius, center - inner_radius, 
                 center + inner_radius, center + inner_radius], 
                fill=(100, 100, 100, 255), outline=(0, 0, 0, 255), width=2)
    
    # Camera lens highlight
    highlight_radius = int(inner_radius * 0.3)
    draw.ellipse([center - highlight_radius, center - highlight_radius, 
                 center + highlight_radius, center + highlight_radius], 
                fill=(200, 200, 200, 180))
    
    # Add small camera icon elements
    camera_size = int(radius * 0.15)
    # Camera flash
    flash_x = center + int(radius * 0.6)
    flash_y = center - int(radius * 0.6)
    draw.ellipse([flash_x - camera_size//2, flash_y - camera_size//2,
                 flash_x + camera_size//2, flash_y + camera_size//2],
                fill=(255, 255, 0, 255), outline=(0, 0, 0, 255), width=2)
    
    return img

def generate_all_sizes():
    """Generate all required app icon sizes"""
    
    # iOS app icon sizes
    sizes = [
        (20, 20), (29, 29), (40, 40), (58, 58), (60, 60), 
        (76, 76), (80, 80), (87, 87), (114, 114), (120, 120),
        (152, 152), (167, 167), (180, 180), (1024, 1024)
    ]
    
    # Create output directory
    output_dir = "app_icons"
    os.makedirs(output_dir, exist_ok=True)
    
    for size in sizes:
        width, height = size
        icon = create_pokemon_app_icon(max(width, height))
        
        # Resize to exact size
        icon = icon.resize((width, height), Image.Resampling.LANCZOS)
        
        # Save with appropriate name
        filename = f"icon_{width}x{height}.png"
        icon.save(os.path.join(output_dir, filename))
        print(f"Generated {filename}")

if __name__ == "__main__":
    print("Generating Pokémon-themed app icons...")
    generate_all_sizes()
    print("✅ App icons generated successfully!")
    print("📁 Icons saved in 'app_icons' folder")

